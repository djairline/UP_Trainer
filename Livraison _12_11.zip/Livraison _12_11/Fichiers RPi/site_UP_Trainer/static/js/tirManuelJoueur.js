$('input').on("change", function () {
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
});

$(".cadence").on("change", function () {
    if ($(this).val() < 7) {
        $(".cadence").val(7);
        $.notify({
            message: "Cadence minimale : 7s"
        }, {
            type: "danger"
        });
    }
});

$('input').trigger("change");


$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

$(".effet").on("input", function () {
    $(".effet").val($(this).val());
});

$(".hauteur").on("input", function () {
    $(".hauteur").val($(this).val());
});

$(".puissance").on("changemax", function (event, arg) {
    if (arg == 'adulte') {
        $(".puissance").attr('max', 10);
    }
    else
    {
        $(".puissance").attr('max', 5);
    }
});

/////////////////////////////////////Liste des fonctions////////////////////////////////////

var countdown = {
    seconds: 0,
    interval: 0,
    callback: null,
    init: function () {
        $("#btn-shoot").addClass("btn-disable");
        $("#pauseButtonBlanc").hide();
        $("#pauseButton").show();
        $("#span-decount").show();
        $("#span-decount").text(countdown.seconds);
        countdown.interval = setInterval(countdown.run, 1000);
    },
    run: function () {
        if (countdown.seconds <= 1) {
            countdown.clear();
            countdown.callback();
        }
        else {
            countdown.seconds = countdown.seconds - 1;
            $("#span-decount").text(countdown.seconds);
        }
    },
    clear: function () {
        clearInterval(countdown.interval);
        $("#span-decount").hide();
        $("#btn-shoot").removeClass("btn-disable");

    }
}

function shoot() {
    $.ajax({
        method: "SHOOT",
        url: "/api/joueur/commande/tir",
        data: $('#formTirJoueur').serialize()
    })
        .done(function (data, status, head) {
        checkAfterShoot();
        checkAlarms();
        if (data.success == true) {
            $.notify({
                message: "Commande recu, tir imminant"
            }, {
                type: "success"
            });
            makeActive(0);
        }
        if (data.success == false) {
            if (data.message == "alarmeProximite") {
                $('#alarmeIntrusionModal').modal('show');

            }
            else {
                $.notify({
                    message: data.message
                }, {
                    type: "danger"
                });
            }
            countdown.clear();
            makeActive(1);
        }
        
    })
        .fail(function () {
        checkAfterShoot();
        checkAlarms();
        $.notify({
            message: "Une erreur de communication s'est produite"
        }, {
            type: "danger"
        });
    });
}

function makeActive(wait) {
    countdown.clear();
    $('#btn-shoot').off("click");
    var shootAndPass = function () {
        shoot();
    }
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
        $('#btn-shoot').one("click", shootAndPass);
    }
    else {
        $("#cadence").show();
        countdown.seconds = $(".cadence").val();
        countdown.callback = shootAndPass;
        if (wait == 1) {
            $('#btn-shoot').one("click", function () { countdown.init() });
        }
        else {
            countdown.init()
        }
    }

}

/////////////////////////////////////Initialisation////////////////////////////////////

$(document).ready(function () {
    makeActive(1);
    $.ajax({
        method: "PREPARE",
        url: "/api/joueur/commande/tir",
        data: $('#formTirJoueur').serialize()
    })
        .done(checkAlarms());
    $("#pauseButtonBlanc").show();
    $("#pauseButton").hide();
});
$('input').on("change", function () {
    makeActive(1);
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
});

$("#formTirJoueur").change(function () {
    $.ajax({
        method: "PREPARE",
        url: "/api/joueur/commande/tir",
        data: $('#formTirJoueur').serialize()
    })
        .done(checkAlarms());
});

/////////////////////////////////////Gestion Des évenements////////////////////////////////////

$("#pauseButton").click(function (e) {
    e.preventDefault(e);
    $("#pauseButtonBlanc").show();
    $("#pauseButton").hide();
    countdown.clear();
    makeActive(1);
});

$("#stopButton").click(function (e) {
    e.preventDefault(e);
    countdown.clear();
    makeActive(1);
    $.ajax({
        method: "STOP",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
        if (data.success == true) {
            $.notify({
                message: "Le tir à bien été annulé"
            }, {
                type: "success"
            });
            $('#arretUrgenceModal').modal('show');
        }
    })
        .fail(function () {
        $.notify({
            message: "Une erreur c'est produite"
        }, {
            type: "danger"
        });
    });
});



$("#rearmButton").click(function () {
    $.ajax({
        method: "REARM",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
        checkAfterShoot();
        checkAlarms();
        if (data.success == true) {
            $.notify({
                message: "Lanceur de nouveau prêt à tirer"
            }, {
                type: "success"
            });
        }
    })
        .fail(function () {
        checkAfterShoot();
        checkAlarms();
        $.notify({
            message: "Une erreur c'est produite"
        }, {
            type: "danger"
        });
    });
});

