var modeAdulte;

$.notifyDefaults({
    placement: {
        from: "bottom",
        align: "right"
    },
    animate: {
        enter: 'animated fadeInUp',
        exit: 'animated fadeOutDown'
    }
});


$(document).ready(function () {
    // Detection du mode adulte
    $.ajax({
        method: "GET",
        url: "/api/parametres/modeAdulte"
    })
        .done(function (data, status, head) {
            modeAdulte = data.modeAdulte;
            if (modeAdulte == true) {
                $("#childIcon").hide();
                $("#childIconCross").show();
            }
            else {
                $("#childIcon").show();
                $("#childIconCross").hide();
            }
        });

    $("#formPinCheck").submit(function (e) {
        e.preventDefault(e);
        $.ajax({
            method: "CHECK",
            url: "/api/parametres/motDePasse",
            data: $(this).serialize(),
        })
            .done(function (data, status, head) {
                if (data.success == false) {
                    $('#pinInput').addClass("is-invalid");
                }
                else {
                    $("#checkPinModal").modal('hide');
                    $("#childIconCross").show(1000);
                    $("#childIcon").hide(1000);
                    $('.puissance').trigger("changemax", 'adulte');
                    location.reload();
                    $.notify({
                        message: "Vous etes à présent en mode adulte",
                    },
                        {
                            type: "success"
                        });
                }
            })
            .fail(function () {
                $.notify({
                    message: "Une erreur c'est produite"
                }, {
                        type: "danger"
                    });
            });
    });

    $("#childModeButton").click(function () {
        $.ajax({
            method: "CANCEL",
            url: "/api/parametres/modeAdulte"
        }).done(function () {
            $("#cancelAdultModal").modal('hide');
            $("#childIcon").show(1000);
            $("#childIconCross").hide(1000);
            $('.puissance').trigger("changemax", 'enfant');
            $.notify({
                message: "Vous etes à présent en mode enfant",
            },
                {
                    type: "success"
                });
            location.reload();
        });
    });

    //Polling
    setInterval(pollingAlarms, 10000);
});





