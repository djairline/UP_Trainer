from flask import Blueprint, jsonify, request, session
from tinydb import TinyDB, where

from server.api.apiTools import checkAlarmeProximite, checkGET_STATUS, checkBatterie, checkLatchErrors, checkBeforeMove
import subprocess


apiParametres = Blueprint('apiParametres', __name__)


@apiParametres.route('/status')
def status():
    if request.method == "GET":
        alarmes = {}
        alarmes['proximite'] = checkAlarmeProximite()
        liste_status = checkGET_STATUS()
        alarmes['arretUrgence'] = liste_status[0]
        alarmes['absenceBallon'] = liste_status[3]
        alarmes['batterie'] = checkBatterie()
        liste_errors = checkLatchErrors()
        if 1 in liste_errors[9:15]:
            alarmes['moteurs'] = "1"
        else:
            alarmes['moteurs'] = "0"
        alarmes['capot'] = liste_errors[8]
        alarmes['temperature'] = liste_errors[3]
        # alarmes['arretPremature']
        return jsonify(success=True, alarmes=alarmes)


@apiParametres.route('/statusAfterShoot')
def statusAfterShoot():
    alarmes = {}
    alarmes['proximite'] = checkAlarmeProximite()
    liste_status = checkGET_STATUS()
    alarmes['arretUrgence'] = liste_status[0]
    alarmes['absenceBallon'] = liste_status[3]
    liste_errors = checkLatchErrors()
    if 1 in liste_errors[9:15]:
        alarmes['moteurs'] = "1"
    else:
        alarmes['moteurs'] = "0"
    alarmes['capot'] = liste_errors[8]
    return jsonify(success=True, alarmes=alarmes)


@apiParametres.route('/modeAdulte', methods=["CANCEL"])
@apiParametres.route('/modeAdulte', methods=["GET"])
def modeAdulte():
    if request.method == "GET":
        if "adulte" in session.keys():
            return jsonify(success=True, modeAdulte=session["adulte"])
        else:
            session["adulte"] = False
            return jsonify(success=True, modeAdulte=session["adulte"])

    if request.method == "CANCEL":
        session["adulte"] = False
        subprocess.run(['static/program/iflanceur', 'CHILD_FLAG=1'])
        return jsonify(success=True)


@apiParametres.route('/motDePasse', methods=["UPDATE", "CHECK"])
def motdepasse():
    parametres = TinyDB('bdd/parametres.json')
    pin = parametres.all()

    if request.method == "CHECK":
        if request.form["pin"] == pin[0].get("pin"):
            session['adulte'] = True
            subprocess.run(['static/program/iflanceur', 'CHILD_FLAG=0'])
            return jsonify(success=True)
        else:
            return jsonify(success=False, error="BadPin")

    if request.method == "UPDATE":
        if request.form["oldPin"] == pin[0].get("pin"):
            if request.form["newPin"] == request.form["newPinCheck"]:
                parametres.upsert({'pin': request.form["newPin"]}, where('pin').exists())
                return jsonify(success=True)
            else:
                return jsonify(success=False, error="BadPinCheck")
        else:
            return jsonify(success=False, error="BadOldPin")


@apiParametres.route('/nombreTir', methods=['GET'])
def nombreTir():
    if request.method == "GET":
        result = subprocess.run(['static/program/iflanceur', 'GET_BALL_SHOT?'], stdout=subprocess.PIPE)
        nombreTir = int(result.stdout.decode('utf-8').rstrip('\n'))
        return jsonify(success=True, nombreTir=nombreTir)


@apiParametres.route('/commande', methods=["REARM"])
@apiParametres.route('/commande', methods=["STOP"])
def commandeGenerale():
    if request.method == "STOP":
        subprocess.run(['static/program/iflanceur', 'STOP_SHOOT'])
        return jsonify(success=True)
    if request.method == "REARM":
        if checkBeforeMove() == False:
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            subprocess.run(['static/program/iflanceur', 'REARM_SHOOT'])
            return jsonify(success=True)
