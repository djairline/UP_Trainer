from flask import session
import subprocess
import time


def checkBeforeMove():
    alarmes = {}
    tirOk = True
    alarmes['proximite'] = checkAlarmeProximite()
    if alarmes['proximite'] == "1":
        tirOk = False
    liste_status = checkGET_STATUS()
    if 1 in liste_status:
        tirOk = False
    alarmes['arretUrgence'] = liste_status[0]
    alarmes['absenceBallon'] = liste_status[3]
    liste_errors = checkLatchErrors()
    if 1 in liste_errors[9:15]:
        tirOk = False
    alarmes['capot'] = liste_errors[8]
    if alarmes['capot'] == 1:
        tirOk = False
    return tirOk


def SHOOT_DELAY(seconds):
    time.sleep(seconds-1)
    subprocess.run(['static/program/iflanceur', 'SHOOT'], stdout=subprocess.PIPE)


def checkAlarmeProximite():
    result = subprocess.run(['static/program/iflanceur', 'GET_INTRUSION?2'], stdout=subprocess.PIPE)
    print(result.stdout)
    #return "0"
    if int(result.stdout.decode('utf-8').rstrip('\n')) < 1500:
        return "1"
    else:
        return "0"


def checkGET_STATUS():
    result = subprocess.run(['static/program/iflanceur', 'GET_STATUS?'], stdout=subprocess.PIPE)
    #return [0,0,0,0]
    return [x for x in format(int(result.stdout.decode('utf-8').rstrip('\n')), '#014b')[2:]][:4]


def checkBatterie():
    result = subprocess.run(['static/program/iflanceur', 'ACTUAL_CURRENT_BAT?'], stdout=subprocess.PIPE)
    #return "180000"
    return result.stdout.decode('utf-8').rstrip('\n')


def checkLatchErrors():

    result = subprocess.run(['static/program/iflanceur', 'GET_LATCH_ERRORS?'], stdout=subprocess.PIPE)
    #return [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    return [x for x in format(int(result.stdout.decode('utf-8').rstrip('\n')), '#017b')[2:]]


def sendChildFlag():
    if "adulte" in session.keys():
        if session['adulte'] == "false":
            subprocess.run(['static/program/iflanceur', 'CHILD_FLAG=1'])
        else:
            subprocess.run(['static/program/iflanceur', 'CHILD_FLAG=0'])
    else:
        subprocess.run(['static/program/iflanceur', 'CHILD_FLAG=1'])


def formatEffet(effet):
    if effet == '-1':
        return '1'
    elif effet == '1':
        return '2'
    else:
        return '0'
