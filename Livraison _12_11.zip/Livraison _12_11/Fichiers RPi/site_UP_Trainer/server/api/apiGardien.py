from flask import Blueprint, jsonify, request, session
from tinydb import TinyDB, where
from operator import itemgetter
from server.api.apiTools import sendChildFlag, checkBeforeMove, checkAlarmeProximite
import subprocess


apiGardien = Blueprint('apiGardien', __name__)


@apiGardien.route('/commande/sequence/<sweep>', methods=['SHOOT'])
@apiGardien.route('/commande/sequence', methods=['STOP'])
def sequenceGardien(sweep):
    if request.method == "SHOOT":
        if checkBeforeMove() == False:
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'RESET_BALL_SHOT'])
            subprocess.run(['static/program/iflanceur', 'SET_PARAM=0,' + request.form["puissance"] + ',1,1,'+session["calibrationVal"], + sweep + ',' + request.form["delais"]] + ',0')
            subprocess.run(['static/program/iflanceur', 'START_SEQUENCE'])
            return jsonify(success=True)

    if request.method == "STOP":
        subprocess.run(['static/program/iflanceur', 'STOP_SEQUENCE'])
        return jsonify(success=True)


@apiGardien.route('/commande/tir', methods=['PREPARE'])
@apiGardien.route('/commande/tir', methods=['SHOOT'])
def commandeGardienManuel():
    if request.method == "SHOOT":
        if checkBeforeMove() == False:
        	if checkAlarmeProximite() =="1":
        		return jsonify(success=False, message = "alarmeProximite")
        	return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=0'])
            subprocess.run(['static/program/iflanceur', 'SET_CALIBRATION='+session["calibrationVal"]])
            num_case = str((4-int(request.form["ordonnee"])) * 7 + int(request.form["abscisse"]))
            subprocess.run(['static/program/iflanceur', 'SHOOT_CASE=' + request.form["puissance"] + "," + num_case])
            return jsonify(success=True)

    if request.method == "PREPARE":
        if checkBeforeMove() == False:
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=0'])
            subprocess.run(['static/program/iflanceur', 'SET_CALIBRATION='+session["calibrationVal"]])
            subprocess.run(['static/program/iflanceur', 'SET_POWER=' + request.form["puissance"]])
            num_case = str((4-int(request.form["ordonnee"]))*7+int(request.form["abscisse"]))
            subprocess.run(['static/program/iflanceur', 'SET_AREA=' + num_case])
            return jsonify(success=True)


@apiGardien.route('/calibration', methods=['POST'])
@apiGardien.route('/calibration', methods=['GET'])
@apiGardien.route('/calibration', methods=['SHOOT'])
def calibrationGardien():
    if request.method == "GET":
        if "calibrationVal" in session.keys() :
            if session["calibrationVal"] != "":
                calibration = session["calibrationVal"]
                return jsonify(success=True, calibration=calibration)
        else :
            session["calibrationVal"] = 10
            session["calibration"]=True
            calibration = 10
            return jsonify(success=True, calibration=calibration)

    if request.method == "POST":
        session['calibration'] = True
        session["calibrationVal"] = request.form["calibrage"]
        return jsonify(success=True)

    if request.method == "SHOOT":
        if checkBeforeMove() == False:
        	if checkAlarmeProximite() =="1":
        		return jsonify(success=False, message = "alarmeProximite")
        	return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=0'])
            subprocess.run(['static/program/iflanceur', 'SET_CALIBRATION='+request.form["calibrage"]])
            num_case = str((4-int(request.form["ordonnee"])) * 7 + int(request.form["abscisse"]))
            subprocess.run(['static/program/iflanceur', 'SHOOT_CASE=' + request.form["puissance"] + "," + num_case])
            return jsonify(success=True)


@apiGardien.route('/data/<programme>', methods=['GET'])
@apiGardien.route('/data/<programme>', methods=["DELETE"])
def programmeGardien(programme):
    tirs = TinyDB('bdd/programmes.json').table('gardienTir')
    programmes = TinyDB('bdd/programmes.json').table('gardienProg')

    if request.method == "GET":
        typeProgramme = programmes.search(where('titre') == programme)[0].get("type")
        tirs = tirs.search(where('programme') == programme)
        tirs = sorted(tirs, key=itemgetter('index'))
        return jsonify(success=True, tirs=tirs, type=typeProgramme)

    if request.method == "DELETE":
        programmes.remove(where('titre') == programme)  # suppression du programme
        tirs.remove(where('programme') == programme)  # suppression des tirs de ce programme
        return jsonify(success=True)


@apiGardien.route('/data/<programme>/<tir>', methods=['GET'])
@apiGardien.route('/data/<programme>/<tir>', methods=['PREPARE'])
@apiGardien.route('/data/<programme>/<tir>', methods=['SHOOT'])
def tirGardien(programme, tir):
    tirs = TinyDB('bdd/programmes.json').table('gardienTir')
    tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
    num_case = str((int(tiroptions[0].get("ordonnee"))-1)*7+int(tiroptions[0].get("abscisse")))

    if request.method == 'POST':
        programmes = TinyDB('bdd/programmes.json').table('gardienProg')
        if tirs.search((where('titre') == tir) & (where('programme') == programme)) == []:
            tirs.insert({
                'index': len(tirs.search(where('programme') == programme)),
                'titre': tir,
                'programme': programme,
                'type': programmes.search(where('titre') == programme)[0].get('type'),
                'puissance': 1,
                'lancement': 'bouton',
                'delais': 7,
                'repetitions': 1,
                'abscisse': 3,
                'ordonnee': 2
            })
            return jsonify(success=True)
        else:
            return jsonify(success=False, message="nameAlreadyExist")

    if request.method == "UPDATE":
        if 'puissance' in request.form:
            tirs.upsert({'puissance': request.form['puissance']}, (where('titre') == tir) & (where('programme') == programme))
        if 'lancement' in request.form:
            tirs.upsert({'lancement': request.form['lancement']}, (where('titre') == tir) & (where('programme') == programme))
        if 'delais' in request.form:
            tirs.upsert({'delais': request.form['delais']}, (where('titre') == tir) & (where('programme') == programme))
        if 'repetitions' in request.form:
            tirs.upsert({'repetitions': request.form['repetitions']}, (where('titre') == tir) & (where('programme') == programme))
        if 'abscisse' in request.form:
            tirs.upsert({'abscisse': request.form['abscisse']}, (where('titre') == tir) & (where('programme') == programme))
        if 'ordonnee' in request.form:
            tirs.upsert({'ordonnee': request.form['ordonnee']}, (where('titre') == tir) & (where('programme') == programme))
        return jsonify(success=True)

    if request.method == "SHOOT":
        if checkBeforeMove() == False:
        	if checkAlarmeProximite() =="1":
        		return jsonify(success=False, message = "alarmeProximite")
        	return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=0'])
            subprocess.run(['static/program/iflanceur', 'SET_CALIBRATION='+session["calibrationVal"]])
            subprocess.run(['static/program/iflanceur', 'SHOOT_CASE=' + tiroptions[0].get("puissance") + "," + num_case])
            return jsonify(success=True)

    if request.method == "GET":
        return jsonify(success=True, tir=tiroptions)

    if request.method == "PREPARE":
        if checkBeforeMove() == False:
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=0'])
            subprocess.run(['static/program/iflanceur', 'SET_CALIBRATION='+session["calibrationVal"]])
            subprocess.run(['static/program/iflanceur', 'SET_POWER=' + str(tiroptions[0].get("puissance"))])
            subprocess.run(['static/program/iflanceur', 'SET_AREA=' + num_case])
            return jsonify(success=True)
