from flask import Blueprint, jsonify, request, session
from tinydb import TinyDB, where
from operator import itemgetter
from server.api.apiTools import sendChildFlag, checkBeforeMove, formatEffet, checkAlarmeProximite
import subprocess

""" Trucs à faire :

* Verifier et enlever type des programmes quand ce dernier sera à maturité

"""
apiJoueur = Blueprint('apiJoueur', __name__)


@apiJoueur.route('/commande/tir', methods=['PREPARE'])
@apiJoueur.route('/commande/tir', methods=['SHOOT'])
def commandeJoueurManuel():
    if request.method == "SHOOT":
        if checkBeforeMove() == True:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=1'])
            subprocess.run(['static/program/iflanceur', 'SET_POWER=' + request.form["puissance"]])
            subprocess.run(['static/program/iflanceur', 'SET_HEIGHT_EFFECT=' + request.form["hauteur"]+','+formatEffet(request.form["effet"])])
            subprocess.run(['static/program/iflanceur', 'SHOOT'])
            return jsonify(success=True)
        else:
            if checkAlarmeProximite() == "1":
                return jsonify(success=False, message = "alarmeProximite")

    if request.method == "PREPARE":
        if checkBeforeMove() == False:
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=1'])
            subprocess.run(['static/program/iflanceur', 'SET_POWER=' + request.form["puissance"]])
            subprocess.run(['static/program/iflanceur', 'SET_HEIGHT=' + request.form["hauteur"]])
            subprocess.run(['static/program/iflanceur', 'SET_EFFECT=' + formatEffet(request.form["effet"])])
            return jsonify(success=True)


@apiJoueur.route('/data/<programme>', methods=['GET'])
@apiJoueur.route('/data/<programme>', methods=['POST'])
@apiJoueur.route('/data/<programme>', methods=["DELETE"])
def programmeJoueur(programme):
    tirs = TinyDB('bdd/programmes.json').table('joueurTir')
    programmes = TinyDB('bdd/programmes.json').table('joueurProg')

    if request.method == "GET":
        typeProgramme = programmes.search(where('titre') == programme)[0].get("type")
        tirs = tirs.search(where('programme') == programme)
        tirs = sorted(tirs, key=itemgetter('index'))
        return jsonify(success=True, tirs=tirs, type=typeProgramme)

    if request.method == "POST":
        if programmes.search(where('titre') == programme) == []:
            programmes.insert({'titre': programme,
                               'type': request.form['type'],
                               'abscisseUpTrainer': request.form['abscisseUpTrainer'],
                               'ordonneeUpTrainer': request.form['ordonneeUpTrainer'],
                               'angleUpTrainer': request.form['angleUpTrainer']
                               })  # ajout du nouveau programme à la base de donnée si le titre est nouveaus
            return jsonify(success=True)
        else:
            message = "nameAlreadyExist"
            return jsonify(success=False, message=message)

    if request.method == "DELETE":
        programmes.remove(where('titre') == programme)  # suppression du programme
        tirs.remove(where('programme') == programme)  # suppression des tirs de ce programme
        return jsonify(success=True)


@apiJoueur.route('/data/<programme>/<tir>', methods=['GET'])
@apiJoueur.route('/data/<programme>/<tir>', methods=['PREPARE'])
@apiJoueur.route('/data/<programme>/<tir>', methods=['SHOOT'])
@apiJoueur.route('/data/<programme>/<tir>', methods=['POST'])
@apiJoueur.route('/data/<programme>/<tir>', methods=['UPDATE'])
@apiJoueur.route('/data/<programme>/<tir>', methods=['DELETE'])
def tirJoueur(programme, tir):
    tirs = TinyDB('bdd/programmes.json').table('joueurTir')
    if request.method == "UPDATE":
        if 'puissance' in request.form:
            tirs.upsert({'puissance': request.form['puissance']}, (where('titre') == tir) & (where('programme') == programme))
        if 'lancement' in request.form:
            tirs.upsert({'lancement': request.form['lancement']}, (where('titre') == tir) & (where('programme') == programme))
        if 'delais' in request.form:
            tirs.upsert({'delais': request.form['delais']}, (where('titre') == tir) & (where('programme') == programme))
        if 'repetitions' in request.form:
            tirs.upsert({'repetitions': request.form['repetitions']}, (where('titre') == tir) & (where('programme') == programme))
        if 'effet' in request.form:
            tirs.upsert({'effet': request.form['effet']}, (where('titre') == tir) & (where('programme') == programme))
        if 'hauteur' in request.form:
            tirs.upsert({'hauteur': request.form['hauteur']}, (where('titre') == tir) & (where('programme') == programme))
        if 'abscisseCible' in request.form:
            tirs.upsert({'abscisseCible': request.form['abscisseCible']}, (where('titre') == tir) & (where('programme') == programme))
        if 'ordonneeCible' in request.form:
            tirs.upsert({'ordonneeCible': request.form['ordonneeCible']}, (where('titre') == tir) & (where('programme') == programme))
        if 'angleUpTrainer' in request.form:
            tirs.upsert({'angleUpTrainer': request.form['angleUpTrainer']}, (where('titre') == tir) & (where('programme') == programme))
        return jsonify(success=True, message="successModif")

    if request.method == "POST":
        programmes = TinyDB('bdd/programmes.json').table('joueurProg')
        if tirs.search((where('titre') == tir) & (where('programme') == programme)) == []:
            tirs.insert({
                'index': len(tirs.search(where('programme') == programme)),
                'titre': tir,
                'programme': programme,
                'type': programmes.search(where('titre') == programme)[0].get('type'),
                'puissance': 1,
                'lancement': 'bouton',
                'delais': 7,
                'repetitions': 1,
                'effet': 0,
                'hauteur': 10,
                'abscisseUpTrainer': programmes.search(where('titre') == programme)[0].get('abscisseUpTrainer'),
                'ordonneeUpTrainer': programmes.search(where('titre') == programme)[0].get('ordonneeUpTrainer'),
                'abscisseCible': -1,
                'ordonneeCible': -1,
                'angleUpTrainer': programmes.search(where('titre') == programme)[0].get('angleUpTrainer')
            })
            return jsonify(success=True, message="successCreation")
        else:
            return jsonify(success=False, message="nameAlreadyExist")
    tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))

    if request.method == "DELETE":
        index = tiroptions[0].get('index')
        tirs.remove((where('titre') == tir) & (where('programme') == programme))
        for i in range(index+1, len(tirs.search((where('programme') == programme))+1)):
            tirs.update({'index': i-1}, (where('index') == i) & (where('programme') == programme))
        return jsonify(success=True)

    if request.method == "SHOOT":
        if checkBeforeMove() == False:
            if checkAlarmeProximite() =="1":
                return jsonify(success=False, message = "alarmeProximite")
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=1'])
            subprocess.run(['static/program/iflanceur', 'SET_POWER=' + str(tiroptions[0].get("puissance"))])
            subprocess.run(['static/program/iflanceur', 'SET_HEIGHT_EFFECT=' + str(tiroptions[0].get("hauteur"))+','+formatEffet(int(tiroptions[0].get("effet")))])
            subprocess.run(['static/program/iflanceur', 'SHOOT'])
            return jsonify(success=True)

    if request.method == "GET":
        return jsonify(success=True, tir=tiroptions)

    if request.method == "PREPARE":
        if checkBeforeMove() == False:
            return jsonify(success=False, message="Une alarme a été déclenchée")
        else:
            sendChildFlag()
            subprocess.run(['static/program/iflanceur', 'TARGET=1'])
            subprocess.run(['static/program/iflanceur', 'SET_POWER=' + str(tiroptions[0].get("puissance"))])
            subprocess.run(['static/program/iflanceur', 'SET_HEIGHT_EFFECT=' + str(tiroptions[0].get("hauteur"))+','+formatEffet(int(tiroptions[0].get("effet")))])
            return jsonify(success=True)
