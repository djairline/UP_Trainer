from flask import Flask, request , render_template, redirect, url_for, Blueprint, jsonify, session
from tinydb import TinyDB, where
webGardien = Blueprint('webGardien', __name__)



#niveau 2 
######################################################################################################
@webGardien.route('/choix/mode')
def choixMode():
	"""
	Rendu de la page permettant de choisir que faire dans le mode gardien ('choixModeGardien.html'): Tir Manuel/ Programmes/ Calibration
	Paramètres IN : []
	Paramètres OUT : []
	Appelants : index.html ; tirManuelGardien.html ; choixProgrammeGardien.html ; calibration.html
	 """
	return render_template('choixModeGardien.html')


#niveau 3 
######################################################################################################
@webGardien.route('/gardien/tir/manuel')
def tirManuel():
	"""
	Rendu de la page pemettant d'effectuer un tir Gardien Manuel (tirManuelGardien.html)
	Paramètres IN : []
	Paramètres OUT : []
	Appelants : choixModeGardien.html
	"""
	return render_template('tirManuelGardien.html')

@webGardien.route('/gardien/calibration')
def calibration():
	"""
	Rendu de la page pemettant d'effectuer la calibration (calibration.html)
	Paramètres IN : []
	Paramètres OUT : []
	Appelants : choixModeGardien.html
	"""
	return render_template('calibration.html')

@webGardien.route('/gardien/choix/programme/')
@webGardien.route('/gardien/choix/programme/<message>')
def choixProg(message = 0):
	"""
	Rendu de la page affichant la liste des programmes gardiens (choixProgGardien.html)
	Paramètres IN : []
	Paramètres OUT : [programmes type=array ; message type=string]
	Appelants : choixModeGardien.html ; choixModeGardienProgramme.html
	"""
	programmes = TinyDB('bdd/programmes.json').table('gardienProg').all() #récupération des programmes dans la base de donnée
	return render_template('choixProgGardien.html', programmes = programmes, message = message)

@webGardien.route('/gardien/ajout/programme', methods=['post'])
def ajouterProg() :
	"""
	Ajout d'un programme gardien
	Paramètres IN : [titre du programme donné dans le modal]
	Paramètres OUT : [message type=string]
	Appelants : choixProgrammeGardien.html
	"""
	programmes = TinyDB('bdd/programmes.json').table('gardienProg')
	if programmes.search(where('titre') == request.form['titreProg'])== []:
		programmes.insert({'titre' : request.form['titreProg'],
		'type': request.form['type']
		}) #ajout du nouveau programme à la base de donnée si le titre est nouveau
		message = None
	else :
		message = "nameAlreadyExist"
	return redirect(url_for('webGardien.choixProg', message = message))
########################################################################################################

#niveau 4
@webGardien.route('/gardien/choix/mode/Programme/<programme>')
def choixModeProgramme(programme):
	"""
	Rendu de la page pemettant de choisir que faire dans le mode gardien programmé après avoir choisi quel programme utiliser
	('choixModeGardienProgramme.html'): Execution/ Visualisation/ Edition
	Paramètres IN : [programme]
	Paramètres OUT : [programme]
	Appelants : choixProgGardien.html ; choixTirGardien.html ; tirGardienProgramme.html ; visualisationTirGardien.html 
	"""
	return render_template('choixModeGardienProgramme.html',programme=programme)

#niveau 5
########################################################################################################
@webGardien.route('/gardien/tirSequence/<sweep>')
def tirSequence(sweep):
	"""
	Rendu de la page pemettant d'éxécuter les tirs séquencé cmme sur l'IHM v1
	('tirGardienProgramme.html')
	Paramètres IN : [sweep]
	Paramètres OUT : [sweep]
	Appelants : choixModeGardienProgramme.html
	"""
	print("here")
	return render_template('tirSequenceGardien.html', sweep = sweep)


@webGardien.route('/gardien/choix/mode/Programme/Tir/<programme>')
@webGardien.route('/gardien/choix/mode/Programme/Tir/<programme>/<tir>')
def tirProgramme(programme,tir=[]):
	"""
	Rendu de la page pemettant d'éxécuter un programme après l'avoir choisis
	('tirGardienProgramme.html')
	Paramètres IN : [programme , tir]
	Paramètres OUT : [programme type = string, (tir type = string), tiroptions type=array contienant les infos du tir]
	Appelants : choixModeGardienProgramme.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	if tir==[]:
		tiroptions = [tirs.search(where('programme') == programme)[0]]
	else : 
		tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	tirs = tirs.search(where('programme') == programme)
	return render_template('tirGardienProgramme.html',programme = programme, tirs = tirs, tiroptions = tiroptions)



@webGardien.route('/gardien/choix/mode/Programme/Visualisation/<programme>')
@webGardien.route('/gardien/choix/mode/Programme/Visualisation/<programme>/<tir>')
def visualisationTir(programme,tir=[]):
	"""
	Rendu de la page pemettant de visualiser un programme après l'avoir choisis
	('tirGardienProgramme.html')
	Paramètres IN : [programme , tir]
	Paramètres OUT : [programme type = string, (tir type = string), tiroptions type=array contienant les infos du tir]
	Appelants : choixModeGardienProgramme.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	if tir==[]:
		tiroptions = [tirs.search(where('programme') == programme)[0]]
	else : 
		tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	tirs = tirs.search(where('programme') == programme)
	return render_template('visualisationTirGardien.html',programme=programme, tirs=tirs, tiroptions=tiroptions)

@webGardien.route('/gardien/choix/tir/<programme>')
@webGardien.route('/gardien/choix/tir/<programme>/<message>')
def choixTir(programme, message = 0):
	"""
	Rendu de la page pemettant de choisir le tir à éditer ou d'éditer/supprimer le programme
	('choixTirGardien.html')
	Paramètres IN : [programme]
	Paramètres OUT : [programme type = string]
	Appelants : choixModeGardienProgramme.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	tirs = tirs.search(where('programme') == programme)
	return render_template('choixTirGardien.html', programme = programme, tirs = tirs, message = message)

@webGardien.route('/gardien/ajout/tir', methods=['post'])
def ajouterTir() :
	"""
	Permet d'ajouter un tir dans la base de donnée du programme et d'en récuperer le nom grace au modal présent de "choixTirGardien.html"
	Paramètres IN : [] récupérés avec le resquest.form : programme ; nom du tir
	Paramètres OUT : [message type = string]
	Appelants : choixTirGardien.html
	"""
	programmes = TinyDB('bdd/programmes.json').table('gardienProg')
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	if tirs.search((where('titre') == request.form['titreTir']) & (where('programme') == request.form['programme']))== []:
		tirs.insert({
			'index' : len(tirs.search(where('programme') == request.form['programme'])),
			'titre' : request.form['titreTir'],
			'programme' : request.form['programme'],
			'type' : programmes.search(where('titre') == request.form['programme'])[0].get('type'),
			'puissance' : 1,
			'lancement': 'bouton',
			'delais' : 7,
			'repetitions' : 1,
			'abscisse' : 3,
			'ordonnee' : 2
			})
		message = None

	else :
		message = "nameAlreadyExist"
	return redirect(url_for('webGardien.choixTir', programme = request.form['programme'], message = message))


@webGardien.route('/gardien/supprimer/programme', methods=['post'])
def supprimerProgGardien():
	"""
	Permet de supprimer le programme dans lequel on se situe depuis la page "choixTirGardien.html" que l'on peut voir comme la page d'édition
	Paramètres IN : [] récupérés avec le resquest.form : programme ; nom du tir
	Paramètres OUT : []
	Appelants : choixTirGardien.html
	"""
	programmes = TinyDB('bdd/programmes.json').table('gardienProg')
	programmes.remove(where('titre') == request.form['titreProg']) #suppression du programme
	tirs = TinyDB('programmes/programmes.json').table('gardienTir')
	tirs.remove((where('programme') == request.form['titreProg'])) #suppression des tirs de ce programme
	return redirect(url_for('choixProgGardien'))

@webGardien.route('/gardien/supprimer/tir', methods=['post'])
def supprimerTir():
	"""
	Permet de supprimer un tir "choixTirGardien.html" que l'on peut voir comme la page d'édition
	Paramètres IN : [] récupérés avec le resquest.form : programme ; nom du tir
	Paramètres OUT : []
	Appelants : choixTirGardien.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	tirs.remove((where('titre') == request.form['titreTir']) & (where('programme') == request.form['programme']))
	return redirect(url_for('webGardien.choixTir',programme = request.form['programme']))


#niveau 6
###############################################################################################################
@webGardien.route('/gardien/creation/tir/<programme>/<tir>')
def creationTir(programme, tir):
	"""
	Rendu de la page "creationTirGardien.html"
	Paramètres IN : [programme type=string, tir type=string]
	Paramètres OUT : [programme type=string, tiroptions type = array contenant les informations du tir]
	Appelants : choixTirGardien.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	return render_template('creationTirGardien.html', programme = programme, tiroptions = tiroptions)



@webGardien.route('/gardien/modifier/tir/<programme>/<tir>', methods=['post'])
def modifierTir(programme, tir):
	"""
	Permet d'enregistrer les paramètres du tir dans la base de données
	Paramètres IN : [programme type=string, tir type=string] récupérés avec le resquest.form : programme ; nom du tir
	Paramètres OUT : [programme type=string, message]
	Appelants : choixTirGardien.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('gardienTir')
	tir = tirs.update( {
					'puissance' : request.form['puissance'],
					'lancement': request.form['lancement'],
					'delais' : request.form['delais'],
					'repetitions' : request.form['repetitions'],
					'abscisse' : request.form['abscisse'],
					'ordonnee' : request.form['ordonnee']
					},
					(where('titre') == tir) & (where('programme') == programme)
					)
	return redirect(url_for('webGardien.choixTir', programme = programme, message = "successModif"))

@webGardien.route('/gardien/tirer/', methods=['post'])
def tirer():
	"""
	Permet d'envoyer un tir Gardien
	Paramètres IN : [] récupérés avec le resquest.form : abscisse ; ordonnee ; puissance
	Paramètres OUT : [] envoie des commandes au soft iflanceur
	Appelants : tirGardienManuel.html ; tirGardienManuel.js ; tirGardienProgramme.html ; tirGardienProgramme.js
	"""
	result = subprocess.run(['static/program/iflanceur', 'TARGET=0'], stdout=subprocess.PIPE)
	print("---------------------------------------------------")
	print("Hauteur du tir : ", request.form["ordonnee"])
	print("Abscisse du tir : ", request.form["abscisse"])
	print("Puissance du tir : ", request.form["puissance"])
	print("---------------------------------------------------")
	num_case = str((4-int(request.form["ordonnee"]))*7+int(request.form["abscisse"]))
	print(num_case)
	result = subprocess.run(['static/program/iflanceur', 'SHOOT_HERE='+ request.form["puissance"] + "," + request.form["abscisse"]], stdout=subprocess.PIPE)
	print(result)
	return redirect(url_for('tirManuelGardien'))
