from flask import Flask, request , render_template, redirect, url_for, Blueprint, jsonify
from tinydb import TinyDB, where
webJoueur = Blueprint('webJoueur', __name__)


@webJoueur.route('/joueur/choix/mode')

def choixMode():
	"""
	Rendu de la page permettant de choisir que faire dans le mode joueur ('choixModeJoueur.html'): Tir Manuel/ Programmes
	Paramètres OUT : []
	Appelants : index.html ; tirManuelJoueur.html ; choixProgrammeJoueur.html
	 """
	return render_template('choixModeJoueur.html')

#page3
###################################################################################
@webJoueur.route('/joueur/tir/manuel')
def tirManuel():
	"""
	Rendu de la page pemettant d'effectuer un tir Joueur Manuel (tirManuelJoueur.html)
	Paramètres IN : []
	Paramètres OUT : []
	Appelants : choixModeJoueur.html
	"""
	return render_template('tirManuelJoueur.html')

@webJoueur.route('/joueur/choix/programme/')
@webJoueur.route('/joueur/choix/programme/<message>')
def choixProg(message = 0):
	"""
	Rendu de la page affichant la liste des programmes joueurs (choixProgJoueur.html)
	Paramètres IN : []
	Paramètres OUT : [programmes type=array ; message type=string]
	Appelants : choixModeJoueur.html ; choixModeJoueurProgramme.html
	"""
	programmes = TinyDB('bdd/programmes.json').table('joueurProg').all() #récupération des programmes dans la base de donnée
	return render_template('choixProgJoueur.html', programmes = programmes, message = message)

@webJoueur.route('/joueur/ajout/programme/penseBete/<programme>/<type>')
def ajouterPositionLanceur(programme,type) :
	"""
	Ajout d'un programme gardien
	Paramètres IN : [titre du programme donné dans le modal]
	Paramètres OUT : [message type=string]
	Appelants : choixProgrammeGardien.html
	"""
	return render_template('penseBetePositionLanceur.html',programme=programme,type = type)



#page4
##################################################################################
@webJoueur.route('/joueur/choix/mode/Programme/<programme>')
def choixModeProgramme(programme):
	"""
	Rendu de la page pemettant de choisir que faire dans le mode joueur programmé après avoir choisi quel programme utiliser
	('choixModeJoueurProgramme.html'): Execution/ Visualisation/ Edition
	Paramètres IN : [programme]
	Paramètres OUT : [programme]
	Appelants : choixProgJoueur.html ; choixTirJoueur.html ; tirJoueurProgramme.html ; visualisationTirJoueur.html 
	"""
	return render_template('choixModeJoueurProgramme.html',programme=programme)

#page5
##################################################################################
@webJoueur.route('/joueur/choix/mode/Programme/Tir/<programme>')
@webJoueur.route('/joueur/choix/mode/Programme/Tir/<programme>/<indexTirActuel>')
def tirProgramme(programme,tir=[], indexTirActuel=0):
	"""
	Rendu de la page pemettant d'éxécuter un programme après l'avoir choisis
	('tirJoueurProgramme.html')
	Paramètres IN : [programme , tir]
	Paramètres OUT : [programme type = string, (tir type = string), tiroptions type=array contienant les infos du tir , rangeTir type = array permettant
	d'indexer la liste]
	Appelants : choixModeJoueurProgramme.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	print("______________________________________________________________")
	if int(indexTirActuel)==0:
		indexTirActuel=0
		tiroptions = [tirs.search(where('programme') == programme)[0]]
	else :
		tir=tirs.search(where('programme') == programme)[int(indexTirActuel)].get('titre')
		print(tir)
		tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	tirs = tirs.search(where('programme') == programme)
	rangeTir=range(len(tirs))
	return render_template('tirJoueurProgramme.html', programme = programme, tirs = tirs, tiroptions = tiroptions, rangeTir = rangeTir, indexTirActuel = indexTirActuel)

#ici viendra la visualisation
@webJoueur.route('/joueur/choix/mode/Programme/Visualisation/<programme>')
@webJoueur.route('/joueur/choix/mode/Programme/Visualisation/<programme>/<tir>')
def visualisationTir(programme,tir=[], indexTirActuel=0):
	"""
	Rendu de la page pemettant de visualiser un programme après l'avoir choisis
	('tirJoueurProgramme.html')
	Paramètres IN : [programme , tir]
	Paramètres OUT : [programme type = string, (tir type = string), tiroptions type=array contienant les infos du tir]
	Appelants : choixModeJoueurProgramme.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	if tir==[]:
		tiroptions = [tirs.search(where('programme') == programme)[0]]
	else : 
		tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	tirs = tirs.search(where('programme') == programme)
	return render_template('visualisationTirJoueur.html',programme=programme, tirs=tirs, tiroptions=tiroptions)

@webJoueur.route('/joueur/choix/tir/<programme>')
@webJoueur.route('/joueur/choix/tir/<programme>/<message>')
def choixTir(programme, message = 0):
	"""
	Rendu de la page pemettant de choisir le tir à éditer ou d'éditer/supprimer le programme
	('choixTirJoueur.html')
	Paramètres IN : [programme]
	Paramètres OUT : [programme type = string]
	Appelants : choixModeJoueurProgramme.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	tirs = tirs.search(where('programme') == programme)
	return render_template('choixTirJoueur.html', programme = programme, tirs = tirs, message = message)


@webJoueur.route('/joueur/ajout/tir', methods=['post'])
def ajouterTir() :
	"""
	Permet d'ajouter un tir dans la base de donnée du programme et d'en récuperer le nom grace au modal présent de "choixTirJoueur.html"
	Paramètres IN : [] récupérés avec le resquest.form : programme ; nom du tir
	Paramètres OUT : [message type = string]
	Appelants : choixTirJoueur.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	programmes = TinyDB('bdd/programmes.json').table('joueurProg')
	if tirs.search((where('titre') == request.form['titreTir']) & (where('programme') == request.form['programme']))== []:
		tirs.insert({
			'index' : len(tirs.search(where('programme') == request.form['programme'])),
			'titre' : request.form['titreTir'],
			'programme' : request.form['programme'],
			'type' : programmes.search(where('titre') == request.form['programme'])[0].get('type'),
			'puissance' : 1,
			'lancement': 'bouton',
			'delais' : 7,
			'repetitions' : 1,
			'effet' : 0,
			'hauteur' : 10,
			'abscisseUpTrainer':programmes.search(where('titre') == request.form['programme'])[0].get('abscisseUpTrainer'),
			'ordonneeUpTrainer':programmes.search(where('titre') == request.form['programme'])[0].get('ordonneeUpTrainer'),
			'abscisseCible':-1,
			'ordonneeCible':-1,
			'angleUpTrainer':programmes.search(where('titre') == request.form['programme'])[0].get('angleUpTrainer')
			})
		message = None

	else :
		message = "nameAlreadyExist"
	return redirect(url_for('webJoueur.choixTir', programme = request.form['programme'], message = message))

#ici viendront supprimertirjoueur et supprimer programme joueur
@webJoueur.route('/joueur/supprimer/tir', methods=['post'])
def supprimerTir():
	"""
	Permet de supprimer un tir "choixTirJoueur.html" que l'on peut voir comme la page d'édition
	Paramètres IN : [] récupérés avec le resquest.form : programme ; nom du tir
	Paramètres OUT : []
	Appelants : choixTirGardien.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	tirSupprime = tirs.search((where('titre') == request.form['titreTir']) & (where('programme') == request.form['programme']))
	index = tirSupprime[0].get('index')
	tirs.remove((where('titre') == request.form['titreTir']) & (where('programme') == request.form['programme']))
	for i in range(index+1,len(tirs.search((where('programme') == request.form['programme'])))+1):
		tirs.update({
			'index' : i-1
			},
			(where('index') == i) & (where('programme') == request.form['programme']))
	return redirect(url_for('webJoueur.choixTir',programme = request.form['programme']))

#ici viendront supprimertirjoueur et supprimer programme joueur

@webJoueur.route('/programmes/positionLanceur/<programme>', methods=['POST'])
def modifierPositionLanceur(programme) :
	"""
	Ajout d'un programme joueur
	Paramètres IN : [titre du programme donné dans le modal]
	Paramètres OUT : [message type=string]
	Appelants : choixProgrammeJoueur.html
	"""
	programmes = TinyDB('bdd/programmes.json').table('joueurProg')
	update = programmes.update( {
			'abscisseUpTrainer':request.form['abscisseUpTrainer'],
			'ordonneeUpTrainer':request.form['ordonneeUpTrainer'],
			'angleUpTrainer':request.form['angleUpTrainer'],
			},
			(where('titre') == programme)
			)
	tirs = TinyDB('bdd/programmes.json').table('joueurProg')
	tirs = tirs.search(where('programme') == programme)
	return redirect(url_for('webJoueur.choixTir', programme = programme))

@webJoueur.route('/joueur/creation/tir/<programme>/<tir>')
def creationTir(programme, tir):
	"""
	Rendu de la page "creationTirJoueur.html"
	Paramètres IN : [programme type=string, tir type=string]
	Paramètres OUT : [programme type=string, tiroptions type = array contenant les informations du tir]
	Appelants : choixTirJoueur.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	return render_template('creationTirJoueur.html', programme = programme, tiroptions = tiroptions)



@webJoueur.route('/joueur/modifier/tir/<programme>/<tir>', methods=['post'])
def modifierTir(programme, tir):
	"""
	Permet d'enregistrer les paramètres du tir dans la base de données
	Paramètres IN : [programme type=string, tir type=string] récupérés avec le resquest.form : puissance ; hauteur ; type de lancement ; delais ; effet
	Paramètres OUT : [programme type=string, message]
	Appelants : choixTirJoueur.html
	"""
	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	tir = tirs.update( {
					'puissance' : request.form['puissance'],
					'lancement': request.form['lancement'],
					'delais' : request.form['delais'],
					'repetitions' : request.form['repetitions'],
					'effet' : request.form['effet'],
					'hauteur' : request.form['hauteur']
					},
					(where('titre') == tir) & (where('programme') == programme)
					)
	return redirect(url_for('webJoueur.choixTir', programme = programme, message = "successModif"))


@webJoueur.route('/joueur/modifier/positionCible/<programme>/<tir>')
def penseBete(programme,tir=[]):
	"""
	Permet le rendu de l'aide mémoire du mode joueur
	Paramètres IN : [programme type=string, tir type=string]
	Paramètres OUT : [programme type=string, tiroptions type = array contenant les paramètres du tir]
	Appelants : créationTirJoueur.html
	"""

	tirs = TinyDB('bdd/programmes.json').table('joueurTir')
	tiroptions = tirs.search((where('titre') == tir) & (where('programme') == programme))
	return render_template('penseBete.html', programme = programme, tiroptions = tiroptions)


