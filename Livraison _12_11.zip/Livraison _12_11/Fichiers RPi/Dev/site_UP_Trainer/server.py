#! /usr/bin/python
# -*- coding:utf-8 -*-

from flask import Flask, request, render_template, redirect, url_for, jsonify, session
from tinydb import TinyDB, where
import os
#os.chdir("/home/pi/Dev/site_UP_Trainer")
from server.web.gardien.webGardien import *
from server.web.joueur.webJoueur import *
from server.api.apiJoueur import *
from server.api.apiGardien import *
from server.api.apiParametres import *


app = Flask(__name__)
app.register_blueprint(apiJoueur, url_prefix='/api/joueur')
app.register_blueprint(apiGardien, url_prefix='/api/gardien')
app.register_blueprint(apiParametres, url_prefix='/api/parametres')
app.register_blueprint(webGardien, url_prefix='/Gardien')
app.register_blueprint(webJoueur, url_prefix='/Joueur')


@app.before_first_request
def init():
    print("init")
    session.clear()
    session['calibration'] = False


@app.route('/')
def accueil():
    return render_template('index.html')


@app.route('/parametres')
def parametres():
    return render_template('parametres.html')


if __name__ == '__main__':
    #app.config['PERMANENT_SESSION_LIFETIME'] = 3600
    app.secret_key = 'pierre et loulou'
    app.run(debug=True, host='0.0.0.0')
