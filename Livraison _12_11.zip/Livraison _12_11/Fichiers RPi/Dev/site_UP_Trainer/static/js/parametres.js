$("#formPinChange").submit(function (e) {
	e.preventDefault(e);
	$.ajax({
		method: "UPDATE",
		url: "/api/parametres/motDePasse",
		data: $(this).serialize(),
	})
		.done(function (data, status, head) {
			if (data.success == false) {
				if (data.error == "BadOldPin") {
					$('#oldPinInput').addClass("is-invalid");
				}
				if (data.error == "BadPinCheck") {
					$('#oldPinInput').removeClass("is-invalid");
					$('#oldPinInput').addClass("is-valid");
					$('#newPinInput').addClass("is-invalid");
					$('#newPinCheckInput').addClass("is-invalid");
				}
			}
			else {
				$("#checkPinModal").modal('hide');
				$.notify({
					message: "Le mot de passe à été modifié"
				},
					{
						type: "success"
					});
			}
		})
		.fail(function () {
			$.notify({
				message: "Une erreur c'est produite"
			}, {
					type: "danger"
				});
		});
});