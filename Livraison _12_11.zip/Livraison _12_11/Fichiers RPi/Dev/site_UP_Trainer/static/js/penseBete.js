var choix_dep_arr = 1;
var largeur_donnee;
var ball_size;
var pos_x;
var pos_y;
var on_off = true;
var up_t = false;
var img_up_t;
var img_up_tf;
var img_cible;
var cible = false;
var abscisseUpTrainer;
var ordonneeUpTrainer;
var abscisseCible;
var ordonneeCible;
var dfx;
var dfy;
var angleUpTrainer;
var angle_tot;
var selector = 1;
var deltaAngle;
function preload() {
    img_up_tf = loadImage('/static/img/BallonFleche.png');
    img_up_t = loadImage('/static/img/Ballon.png');
    img_cible = loadImage('/static/img/Target.png');
}

function setup() {

    //Ici replace la largeur de la div
    if (window.innerHeight > window.innerWidth) {
        largeur = $('#penseBete').height() / 0.6;
    }
    else {
        largeur = Math.min($('#penseBete').width(), ($(window).height() - $(":header").height()) * 0.95);
    }
    abscisseUpTrainer = Number($("[name=abscisseUpTrainer]").val());
    ordonneeUpTrainer = Number($("[name=ordonneeUpTrainer]").val());
    abscisseCible = Number($("[name=abscisseCible]").val());
    ordonneeCible = Number($("[name=ordonneeCible]").val());
    angleUpTrainer = Number($("[name=angleUpTrainer]").val());

    if (abscisseUpTrainer == '' && ordonneeUpTrainer == '') {
        up_t = false;
    }
    else {
        up_t = true;
    }
    if (abscisseCible > 0 && ordonneeCible > 0) {
        cible = true;
    }
    else {
        cible = false;
    }
    var can = createCanvas(largeur, 0.6 * largeur);
    can.parent('#penseBete');
}

function draw() {
    angleUpTrainer = $("input[name='angleUpTrainer']").val() / 360 * 2 * PI;
    abscisseUpTrainer = Number($("[name=abscisseUpTrainer]").val());
    ordonneeUpTrainer = Number($("[name=ordonneeUpTrainer]").val());
    abscisseCible = Number($("[name=abscisseCible]").val());
    ordonneeCible = Number($("[name=ordonneeCible]").val());

    background(41, 142, 44);
    fill(41, 142, 44);
    stroke(255);
    strokeWeight(10);

    //Surface
    rect(0.2 * largeur, 0.36 * largeur, 0.6 * largeur, 0.24 * largeur);

    //6 mètres
    rect(0.35 * largeur, 0.52 * largeur, 0.3 * largeur, 0.08 * largeur);

    //Point de pénalty
    fill(255);
    noStroke();
    ellipse(0.5 * largeur, 0.44 * largeur, 15, 15);

    //Arc surface de réparation
    noFill();
    stroke(255);
    arc(0.5 * largeur, 0.44 * largeur, 0.27 * largeur, 0.27 * largeur, 3.8, -0.65);

    //Corner
    arc(0, 0.6 * largeur, 0.1 * largeur, 0.1 * largeur, 3 / 4 * PI, 0);
    arc(largeur, 0.6 * largeur, 0.1 * largeur, 0.1 * largeur, PI, 3 / 4 * PI);
    //Grid
    /*    for (var x = 0; x < width; x += width / 10) {
        for (var y = 0; y < height; y += height / 5) {
            stroke(0);
            strokeWeight(1);
            line(x, 0, x, height);
            line(0, y, width, y);
        }
    }
    */
    /*    bezier(0, 0, 150, 0, 400, 150, 400, 400);
    triangle(400,380,380,400,400,400);*/
    if (cible && up_t) {
        //Dessin de la trajectoire
        stroke(100, 178, 255);
        noFill();
        strokeWeight(10);
        if (abscisseCible > abscisseUpTrainer) {
            angle_tot = Math.atan((ordonneeCible - ordonneeUpTrainer) / (abscisseCible - abscisseUpTrainer));
        }
        else {
            angle_tot = PI + Math.atan((ordonneeCible - ordonneeUpTrainer) / (abscisseCible - abscisseUpTrainer));
        }
        deltaAngle = angle_tot - angleUpTrainer;
        if (deltaAngle > 2 * PI) {
            deltaAngle = deltaAngle - 2 * PI;
        }
        if (deltaAngle < 0) {
            deltaAngle = deltaAngle + 2 * PI;
        }
        if (3 * PI / 2 < (deltaAngle) && (deltaAngle) < PI / 2) {
            var d = -(Math.sqrt((-abscisseUpTrainer + abscisseCible) * (-abscisseUpTrainer + abscisseCible) + (-ordonneeUpTrainer + ordonneeCible) * (-ordonneeUpTrainer + ordonneeCible))) / 2;
            var e = d / Math.cos(angle_tot - angleUpTrainer);
            dfx = e * cos(angleUpTrainer);
            dfy = e * sin(angleUpTrainer);

            beginShape();
            vertex(abscisseUpTrainer, ordonneeUpTrainer);
            quadraticVertex(abscisseUpTrainer + dfx, ordonneeUpTrainer + dfy, abscisseCible, ordonneeCible); //On multiplie par 0.8 pour etre en accord avec la distance empirique
            endShape();
            //ellipse(abscisseUpTrainer+dfx, ordonneeUpTrainer+dfy,10,10);
        }
        else {
            var d = (Math.sqrt((-abscisseUpTrainer + abscisseCible) * (-abscisseUpTrainer + abscisseCible) + (-ordonneeUpTrainer + ordonneeCible) * (-ordonneeUpTrainer + ordonneeCible))) / 2;
            var e = d / Math.cos(angle_tot - angleUpTrainer);
            dfx = e * cos(angleUpTrainer);
            dfy = e * sin(angleUpTrainer);

            beginShape();
            vertex(abscisseUpTrainer, ordonneeUpTrainer);
            quadraticVertex(abscisseUpTrainer + dfx, ordonneeUpTrainer + dfy, abscisseCible, ordonneeCible); //On multiplie par 0.8 pour etre en accord avec la distance empirique
            endShape();
            //ellipse(abscisseUpTrainer+dfx, ordonneeUpTrainer+dfy,10,10);
        }
    }
    noStroke();
    if (up_t) {
        fill(255);
        ellipse(abscisseUpTrainer, ordonneeUpTrainer, 0.07 * largeur, 0.07 * largeur);
        translate(abscisseUpTrainer, ordonneeUpTrainer);
        rotate(angleUpTrainer);
        image(img_up_tf, -0.04 * largeur, -0.04 * largeur, 0.16 * largeur, 0.08 * largeur);

        rotate(-angleUpTrainer);
        translate(-abscisseUpTrainer, -ordonneeUpTrainer);



    }

    if (cible) {
        fill(255);
        ellipse(abscisseCible, ordonneeCible, 0.05 * largeur, 0.05 * largeur);
        image(img_cible, abscisseCible - 0.04 * largeur, ordonneeCible - 0.04 * largeur, 0.08 * largeur, 0.08 * largeur);
    }


}

function mousePressed() {
    if (sweepcode == 1) {
        if (mouseX < largeur) {
            if (selector == 1) {
                up_t = true;
                abscisseUpTrainer = parseInt(mouseX);
                ordonneeUpTrainer = parseInt(mouseY);
                $("[name=abscisseUpTrainer]").val(abscisseUpTrainer);
                $("[name=ordonneeUpTrainer]").val(ordonneeUpTrainer);
                $("[name=abscisseUpTrainer]").trigger("change");
            }
            if (selector == 2) {
                cible = true;
                abscisseCible = parseInt(mouseX);
                ordonneeCible = parseInt(mouseY);
                $("[name=abscisseCible]").val(abscisseCible);
                $("[name=ordonneeCible]").val(ordonneeCible);
                $("[name=abscisseCible]").trigger("change");
            }
        }
    }
}

function windowResized() {    //Ici replace la largeur de la div
    if (window.innerHeight > window.innerWidth) {
        largeur = $('#penseBete').height() / 0.6;
    }
    else {
        largeur = Math.min($('#penseBete').width(), ($(window).height() - $(":header").height()) * 0.95);
    }
    resizeCanvas(largeur, 0.6 * largeur);
}
