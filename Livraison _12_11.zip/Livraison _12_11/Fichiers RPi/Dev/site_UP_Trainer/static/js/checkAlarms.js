function checkAfterShoot() {
    setTimeout(function(){ 
        $.ajax({
            method: "GET",
            url: "/api/parametres/statusAfterShoot"
        })
            .done(function (data, status, head) {
            $("#wifiIcon").addClass("icon-signal_wifi_4_bar");
            $("#wifiIcon").removeClass("icon-signal_wifi_off");
            if (data.alarmes.proximite == "1") {
                $.notify({
                    message: "Alarme de proximité déclenchée"
                },
                         {
                    type: "danger"
                });
            }
            if (data.alarmes.arretUrgence == "1") {
                $('#arretUrgenceModal').modal('show');
            }
            if (data.alarmes.absenceBallon == "1") {
                $('#absenceBallonModal').modal('show');
            }
            if (data.alarmes.capot == "1") {
                $('#alarmeCapotModal').modal('show');
            }
            if(data.alarmes.moteurs == "1")
            {
                $('#alarmeMoteurModal').modal('show');
            }
            if(data.alarmes.temperature == "1")
            {
                $('#alarmeTemperatureModal').modal('show');
            }
        })
            .fail(function () {
            $("#wifiIcon").removeClass("icon-signal_wifi_4_bar");
            $("#wifiIcon").addClass("icon-signal_wifi_off");
        });
    }, 7000);
}

function checkAlarms() {
    $.ajax({
        method: "GET",
        url: "/api/parametres/status"
    })
        .done(function (data, status, head) {
        $("#wifiIcon").addClass("icon-signal_wifi_4_bar");
        $("#wifiIcon").removeClass("icon-signal_wifi_off");
        if (data.alarmes.proximite == "1") {
            $.notify({
                message: "Alarme de proximité déclenchée"
            },
                     {
                type: "danger"
            });
        }
        if (data.alarmes.arretUrgence == "1") {
            $('#arretUrgenceModal').modal('show');
        }
        if (data.alarmes.absenceBallon == "1") {
            $('#absenceBallonModal').modal('show');
        }
        if (data.alarmes.capot == "1") {
            $('#alarmeCapotModal').modal('show');
        }

        $("#batteryIcon").removeClass("icon-car_battery_full icon-car_battery_75 icon-car_battery_50 icon-car_battery_25 icon-car_battery_empty");
        if (data.alarmes.batterie < "107000") {
            $('#alarmeBatterieModal').modal('show');
            $("#batteryIcon").addClass("icon-car_battery_empty");
        }
        else if (data.alarmes.batterie < "134250") {
            $("#batteryIcon").addClass("icon-car_battery_25");
        }
        else if (data.alarmes.batterie < "161500") {
            $("#batteryIcon").addClass("icon-car_battery_50");
        }
        else if (data.alarmes.batterie < "188750") {
            $("#batteryIcon").addClass("icon-car_battery_75");
        }
        else {
            $("#batteryIcon").addClass("icon-car_battery_full");
        }
        if(data.alarmes.moteurs == "true")
        {
            $('#alarmeMoteurModal').modal('show');
        }
        if(data.alarmes.temperature == "1")
        {
            $('#alarmeTemperatureModal').modal('show');
        }
    })
        .fail(function () {
        $("#wifiIcon").removeClass("icon-signal_wifi_4_bar");
        $("#wifiIcon").addClass("icon-signal_wifi_off");
    });
}

function pollingAlarms() {
    $.ajax({
        method: "GET",
        url: "/api/parametres/status"
    })
        .done(function (data, status, head) {
        $("#wifiIcon").addClass("icon-signal_wifi_4_bar");
        $("#wifiIcon").removeClass("icon-signal_wifi_off");
        if (data.alarmes.proximite == "1") {
            $.notify({
                message: "Alarme de proximité déclenchée"
            },
                     {
                type: "danger"
            });
        }
        $("#batteryIcon").removeClass("icon-car_battery_full icon-car_battery_75 icon-car_battery_50 icon-car_battery_25 icon-car_battery_empty");
        if (data.alarmes.batterie < "107000") {
            $('#alarmeBatterieModal').modal('show');
            $("#batteryIcon").addClass("icon-car_battery_empty");
        }
        else if (data.alarmes.batterie < "134250") {
            $("#batteryIcon").addClass("icon-car_battery_25");
        }
        else if (data.alarmes.batterie < "161500") {
            $("#batteryIcon").addClass("icon-car_battery_50");
        }
        else if (data.alarmes.batterie < "188750") {
            $("#batteryIcon").addClass("icon-car_battery_75");
        }
        else {
            $("#batteryIcon").addClass("icon-car_battery_full");
        }
        if(data.alarmes.temperature == "1")
        {
            $('#alarmeTemperatureModal').modal('show');
        }
    })
        .fail(function () {
        $("#wifiIcon").removeClass("icon-signal_wifi_4_bar");
        $("#wifiIcon").addClass("icon-signal_wifi_off");
    })
}