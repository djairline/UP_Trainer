console.log("hi")

$("#calibrageButton").click(function (e) {
    e.preventDefault(e);
    window.location.href = "/Gardien/gardien/calibration";
});