$('input').trigger("change");



$(".angleupt").on("input", function () {
    $(".angleupt").val($(this).val());
});


$("#positionLanceurForm").submit(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "POST",
        url: "/api/joueur/data/" + programme,
        data: $(this).serialize()
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                window.location.href = "/Joueur/joueur/choix/tir/" + programme + "/successCreationProgram"
            }
            if (data.success == false) {
                window.location.href = "/Joueur/joueur/choix/programme/" + data.message
            }
        })
        .fail(function () {
            window.location.href = "/Joueur/joueur/choix/programme/Erreur : programme non enregistré"
        })
});
