////////////////////////////////////Décalration variables////////////////////////////////////

var typeProgramme = "Enfant";

//////////////////////////////////// Définition des fonctions ///////////////////////////////

function makeActive(index) {

    $('.liste-texte').removeClass('active');
    $("#tir" + index).addClass('active');
    $("#indexRepetition").remove();
    $("#tir" + index).append("<span id='indexRepetition' class='ml-auto mr-4 badge badge-light'> x " + tirs[index].repetitions + "</span>");
    $('input[name=delais]').val(tirs[index].delais);
    $('input[name=puissance]').val(tirs[index].puissance);
    $('input[name=abscisse]').val(tirs[index].abscisse);
    $('input[name=ordonnee]').val(tirs[index].ordonnee);


    if (tirs[index].lancement == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
}


/////////////////////////////////// Code ////////////////////////////////:

$(document).ready(function () {
    $.ajax({
        method: "GET",
        url: "/api/gardien/data/" + programme
    })
        .done(function (data, status) {
            typeProgramme = data.type;
            var nbTir = 0;
            tirs = data.tirs;
            for (var tir in tirs) {
                $("#items").append("<li class='liste-texte tirProg' id='tir" + tir + "'>" + tirs[tir].titre + "</li>");
                nbTir = nbTir + parseInt(tirs[tir].repetitions);
            }

            $("#nbTir").text(nbTir);
            makeActive(0);

            $('.liste-texte').click(function () {
                makeActive($('.liste-texte').index($(this)));
            });
        });
});