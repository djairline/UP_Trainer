////////////////////////////////////Décalration variables////////////////////////////////////

var typeProgramme = "Enfant";

////////////////////////////////////Gestion des évenements///////////////////////////////////

$('input').on("change", function () {
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
});

$(".cadence").on("change", function () {
    if ($(this).val() < 7) {
        $(".cadence").val(7);
        $.notify({
            message: "Cadence minimale : 7s"
        }, {
                type: "danger"
            });
    }
});

$('input').trigger("change");


$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

$(".horizontal").on("input", function () {
    $(".horizontal").val($(this).val());
});

$(".vertical").on("input", function () {
    $(".vertical").val($(this).val());
});

$(".tirCreationForm").on("change", function () {
    if ($(this).get(0).checkValidity()) {
        $("#bouton").prop('disabled', false);
    }
    else {
        $("#bouton").prop('disabled', true);
    }
});

$(".tirCreationForm").trigger("change");


/////////////////////////////////////////Récupération des paramètres///////////////////////////////

$.ajax({
    method: "GET",
    url: "/api/gardien/data/" + programme
})
    .done(function (data, status) {
        typeProgramme = data.type;
    });