$('input').trigger("change");

$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

$(".horizontal").on("input", function () {
    $(".horizontal").val($(this).val());
});

$(".vertical").on("input", function () {
    $(".vertical").val($(this).val());
});

$(".calibrage").on("input", function () {
    $(".calibrage").val($(this).val());
});

$(".puissance").on("changemax", function (event, arg) {
    if (arg == 'adulte') {
        console.log("there");
        $(".puissance").attr('max', 6);
        $(".puissance").val(1);
    }
});
$.ajax({
    method: "GET",
    url: "/api/gardien/calibration"
})
    .done(function (data, status, head) {
        if (data.success == true) {
            $(".calibrage").val(data.calibration);
        }
        if (data.success == false) {
            $.notify({
                message: "Erreur"
            }, {
                    type: "danger"
                });
        }
    })
    .fail(function () {
        $.notify({
            message: "Une erreur c'est produite"
        }, {
                type: "danger"
            });
    });


$("#shootButton").click(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "SHOOT",
        url: "/api/gardien/calibration",
        data: $("#formCalibration").serialize()
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Commande recu, tir imminant"
                }, {
                        type: "success"
                    });
            }
            if (data.success == false) {
                $.notify({
                    message: data.message
                }, {
                        type: "danger"
                    });
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});


$("#formCalibration").submit(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "POST",
        url: "/api/gardien/calibration",
        data: $(this).serialize()
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "Calibration enregistré"
                }, {
                        type: "success"
                    });
                setTimeout(function () { window.location.href = "/Gardien/choix/mode" }, 1000)
            }
            if (data.success == false) {
                $.notify({
                    message: "Erreur"
                }, {
                        type: "danger"
                    });
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});



$("#stopButton").click(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "STOP",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "Le tir à bien été annulé"
                }, {
                        type: "success"
                    });
                $('#alarmeIntrusionModal').modal('show');
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});

$("#rearmButton").click(function () {
    $.ajax({
        method: "REARM",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Lanceur de nouveau prêt à tirer"
                }, {
                        type: "success"
                    });
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});