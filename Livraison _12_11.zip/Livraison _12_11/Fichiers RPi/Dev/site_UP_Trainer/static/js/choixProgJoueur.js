$("#ajoutProgrammeForm").submit(function(e){
    e.preventDefault(e);
    $("#newProgModal").modal('hide');
    $("#demandePosition").modal('show');
    formData = $(this).serializeArray();
    programme = formData[0].value;
    type = formData[1].value;
});

$("#indiquePosition").click(function(){
    $("#demandePosition").modal('hide');
    window.location.href = "/Joueur/joueur/ajout/programme/penseBete/"+programme+"/"+type;
});