$('input').on("change", function () {
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
});

$('input').trigger("change");


$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

$(".effet").on("input", function () {
    $(".effet").val($(this).val());
});

$(".hauteur").on("input", function () {
    $(".hauteur").val($(this).val());
});

$(".puissance").on("changemax", function (event, arg) {
    if (arg == 'adulte') {
        $(".puissance").attr('max', 10);
    }
});

$("#formTirJoueur").submit(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "SHOOT",
        url: "/api/joueur/commande/tir",
        data: $(this).serialize()
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Commande recu, tir imminant"
                }, {
                        type: "success"
                    });
            }
            if (data.success == false) {
                if (data.message == "alarmeProximite") {
                    $('#alarmeIntrusionModal').modal('show');

                }
                else {
                    $.notify({
                        message: data.message
                    }, {
                            type: "danger"
                        });
                }

            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur de communication s'est produite"
            }, {
                    type: "danger"
                });
        });
});


$("#formTirJoueur").change(function () {
    $.ajax({
        method: "PREPARE",
        url: "/api/joueur/commande/tir",
        data: $(this).serialize()
    })
        .done(checkAlarms());
});




$("#stopButton").click(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "STOP",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "Le tir à bien été annulé"
                }, {
                        type: "success"
                    });
                $('#arretUrgenceModal').modal('show');
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});

$("#rearmButton").click(function () {
    $.ajax({
        method: "REARM",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Lanceur de nouveau prêt à tirer"
                }, {
                        type: "success"
                    });
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});