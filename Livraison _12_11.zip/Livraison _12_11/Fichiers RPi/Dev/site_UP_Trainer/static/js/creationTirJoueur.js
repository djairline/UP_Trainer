$('input').on("change", function () {
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
});

$(".cadence").on("change", function () {
    if ($(this).val() < 7) {
        $(".cadence").val(7);
        $.notify({
            message: "Cadence minimale : 7s"
        }, {
                type: "danger"
            });
    }
});


$('input').trigger("change");


$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

$(".effet").on("input", function () {
    $(".effet").val($(this).val());
});

$(".hauteur").on("input", function () {
    $(".hauteur").val($(this).val());
});


$(".tirCreationForm").on("change", function () {
    if ($(this).get(0).checkValidity()) {
        $("#bouton").prop('disabled', false);
        $("#aideMemoire").prop('disabled', false);
    }
    else {
        $("#bouton").prop('disabled', true);
        $("#aideMemoire").prop('disabled', true);
    }
});

$(".tirCreationForm").trigger("change");



$("#aideMemoire").click(function (e) {

    $.ajax({
        method: "POST",
        url: "/api/joueur/data/" + programme + "/" + tir,
        data: $("#tirCreationForm").serialize()
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "Modifications enregistrées"
                }, {
                        type: "success"
                    });
            }
            if (data.success == false) {
                $.notify({
                    message: "Modifcations non enregistrées"
                }, {
                        type: "danger"
                    });
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});
