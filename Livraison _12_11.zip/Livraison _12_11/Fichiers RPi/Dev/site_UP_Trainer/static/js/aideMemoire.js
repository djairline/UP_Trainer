$('input').trigger("change");

$(".angleupt").on("input", function () {
    $(".angleupt").val($(this).val());
});

$.ajax({
    method: "PREPARE",
    url: "/api/joueur/data/" + programme + "/" + tiroptions.index,
    data: $(this).serialize()
});

$("#positionCibleForm").submit(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "UPDATE",
        url: "/api/joueur/data/" + programme + "/" + tiroptions.titre,
        data: $(this).serialize()
    })
        .done(function (data, status, head) {
            console.log("Coucou");
            if (data.success == true) {
                window.location.href = "/Joueur/joueur/choix/tir/" + programme + "/successModif"
            }
        })
});

$("#shootButton").click(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "SHOOT",
        url: "/api/joueur/data/" + programme + "/" + tiroptions.index,
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Commande recu, tir imminant"
                },
                    {
                        type: "success"
                    });
            }
            if (data.success == false) {
                $.notify({
                    message: data.message
                }, {
                        type: "danger"
                    });
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});

$("#stopButton").click(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "STOP",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "Le tir à bien été annulé"
                }, {
                        type: "success"
                    });
                $('#alarmeIntrusionModal').modal('show');
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});

$("#rearmButton").click(function () {
    $.ajax({
        method: "REARM",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Lanceur de nouveau prêt à tirer"
                }, {
                        type: "success"
                    });
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});