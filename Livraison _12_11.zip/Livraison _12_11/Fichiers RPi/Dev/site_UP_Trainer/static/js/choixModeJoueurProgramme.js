$(document).ready(function () {
    $.ajax({
        method: "GET",
        url: "/api/joueur/data/" + programme
    })
        .done(function (data, status) {
            tirs = data.tirs;
            if (tirs == 0) {
                $("#executeButton").addClass("disabled");
                $("#executeLink").click(function (e) {
                    e.preventDefault();
                    $("#oneShootMinimumModal").modal('show');
                });
                $("#visualiseButton").addClass("disabled");
                $("#visualiseLink").click(function (e) {
                    e.preventDefault();
                    $("#oneShootMinimumModal").modal('show');
                });
            }
        });
});