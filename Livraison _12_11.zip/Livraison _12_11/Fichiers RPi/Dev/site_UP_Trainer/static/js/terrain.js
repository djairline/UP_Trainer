var largeur;
var hauteur ;
var up_t=false;
var cible=false;
var selector=1;
var effet = 0;
var rayon;
var P1_x,P1_y;
var P2_x,P2_y;
var P3_x,P3_y;
var puissance = 10;
var v0;
var hauteur = 10;
var angle;
var distance;
var distance_dess;
var comp_pers;
var comp_effx;
var comp_effy;

var ballon;
function preload() {
    ballon = loadImage('/static/img/Ballon.png');
}

function setup() {
    
    //Ici replace la largeur de la div
    if(window.innerHeight > window.innerWidth)
    {
        largeur = $('#terrain').height();
    }
    else
    {
        largeur = $('#terrain').width()*0.95 ;
    }
    var can = createCanvas(largeur, largeur*0.5);
    can.parent('#terrain');
}

function draw() {

    puissance = $("input[name='puissance']").val();
    hauteur = $("input[name='hauteur']").val();
    effet = $("input[name='effet']").val()*5;


    //Calcul des données utiles au premier graph
    angle = hauteur*4.5*PI/360 //ici il faut qu'on demande l'angle d'incidence max à Antoine
    v0=sqrt(puissance*6*10/sin(PI/2));
    distance = v0*v0/10*sin(2*angle);
    distance_dess=distance/85*largeur/0.80; //On divise par 0.8 pour prendre en compte les effets de frottement dans le dessin on divise par 80 et non par 100 pour agrandir
    //Dessin du premier graph
    background(255);
    //Dessin du sol
    noStroke();
    fill(34, 139, 34);
    quad(0.1*largeur, 0.15*largeur, 0.9*largeur, 0.15*largeur, largeur, 0.45*largeur, 0, 0.45*largeur);
    fill(127, 213, 73);
    quad(0.26*largeur, 0.15*largeur, 0.42*largeur, 0.15*largeur, 0.38*largeur, 0.45*largeur, 0.19*largeur, 0.45*largeur);
    quad(0.73*largeur, 0.15*largeur, 0.58*largeur, 0.15*largeur, 0.60*largeur, 0.45*largeur, 0.80*largeur, 0.45*largeur);
    stroke(255);
    strokeWeight(8);
    line(0.03*largeur,0.45*largeur,0.13*largeur,0.15*largeur);
    strokeWeight(5);
    noFill()
    ellipse(0.08*largeur, 0.29*largeur, 0.27*largeur, 0.22*largeur);
    //Calcul de la trajectoire non freinée

    P1_x=0.2*largeur;
    P1_y=0.3*largeur;
    comp_pers = (-largeur*0.3+distance_dess*0.8)*distance*effet/5000;
    comp_effx = abs(effet)/80;
    comp_effy = effet*distance_dess/50;
    P3_x=P1_x+distance_dess*0.80*(1-comp_effx)+comp_pers;
    P3_y=P1_y+comp_effy;
    P2_x=P1_x+distance_dess*(1-comp_effx)/2.+comp_pers;
    P2_y=P1_y-distance_dess/2*tan(angle)+comp_effy;
    //Dessin de la trajectoire
    stroke(100,178,255);
    noFill();
    strokeWeight(10);
    beginShape();
    vertex(P1_x, P1_y);
    quadraticVertex(P2_x, P2_y, P3_x, P3_y); //On multiplie par 0.8 pour etre en accord avec la distance empirique
    endShape();

    //Dessin du premier ballon 
    noStroke();
    fill(255);
    ellipse(int(0.15*largeur), int(0.27*largeur), int(0.09*largeur), int(0.1*largeur))
    image(ballon, int(0.1*largeur), int(0.22*largeur), int(0.1*largeur), int(0.1*largeur));


}

function windowResized()
{    //Ici replace la largeur de la div
    if(window.innerHeight > window.innerWidth)
    {
        largeur = $('#terrain').height();
    }
    else
    {
        largeur = $('#terrain').width()*0.95;
    }
    resizeCanvas(largeur, largeur*0.5);
}