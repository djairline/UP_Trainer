var choix_dep_arr = 1;
var largeur;
var largeur_donnee;
var largeur_case;
var marge;
var hauteur;
var abscisse;
var ordonnee;
var ball_size;
var pos_x;
var pos_y;
var on_off = false;
var on_off_horizontale = false;
var on_off_verticale = false;
var on_off_aleatoire = false;
var ballon;

function preload() {
    ballon = loadImage('/static/img/Ballon.png');
}

function setup() {

    if (typeof (typeProgramme) === "undefined") {
        typeProgramme = "Manuel";
    }
    largeur_donnee = $("#cage").width() * 0.95;
    marge = int(0.03 * largeur_donnee);
    int_poteau = int(0.06 * largeur_donnee);
    largeur_case = int(0.12 * largeur_donnee);
    largeur = int_poteau * 2 + 7 * largeur_case;
    hauteur = 4 * largeur_case + int_poteau;
    ball_size = int(0.9 * largeur_case);

    if (sweepcode == 0) {
        on_off_aleatoire = true;
        frameRate(1);
    }
    abscisse = $("[name=abscisse]").val();
    ordonnee = $("[name=ordonnee]").val();

    pos_x = abscisse * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
    pos_y = hauteur - ordonnee * largeur_case + (largeur_case - ball_size) / 2;

    if (abscisse == '' && ordonnee == '') {
        on_off = false;
    }
    else {
        on_off = true;
    }

    var can = createCanvas(largeur, hauteur + 10);
    can.parent('#cage');
}

function draw() {
    abscisse = $("[name=abscisse]").val();
    ordonnee = $("[name=ordonnee]").val();
    pos_x = abscisse * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
    pos_y = hauteur - ordonnee * largeur_case + (largeur_case - ball_size) / 2;


    background(255);
    stroke(0);

    //modeEnfant
    if (modeAdulte == false || typeProgramme == "Enfant") {
        strokeWeight(0);
        fill(219, 219, 219);
        rect(int_poteau, int_poteau, largeur_case, 4 * largeur_case);
        rect(int_poteau + 6 * largeur_case, int_poteau, largeur_case, 4 * largeur_case);
        rect(int_poteau, int_poteau, largeur_case * 7, largeur_case);
        noFill();
    }


    //Dessin de la grosse cage
    strokeWeight(5);
    line(marge, marge, largeur - marge, marge);
    line(marge, marge, marge, hauteur);
    line(largeur - marge, marge, largeur - marge, hauteur);
    line(int_poteau, hauteur, int_poteau, int_poteau);
    line(largeur - int_poteau, hauteur, largeur - int_poteau, int_poteau);
    line(int_poteau, int_poteau, largeur - int_poteau, int_poteau);

    //Dessin des deux petites cages
    rect(int_poteau + largeur_case, int_poteau + largeur_case, 5 * largeur_case, 3 * largeur_case);
    rect(int_poteau + 2 * largeur_case, int_poteau + 2 * largeur_case, 3 * largeur_case, 2 * largeur_case);

    //Dessin de la ligne du bas
    strokeWeight(10);
    line(0, hauteur, largeur, hauteur);

    //Grille
    strokeWeight(2);
    for (var x = int_poteau + largeur_case; x < largeur - int_poteau; x = x + largeur_case) {
        for (var y = hauteur; y > int_poteau; y = y - largeur_case) {
            line(x, hauteur, x, int_poteau);
            line(int_poteau, y, largeur - int_poteau, y);
        }
    }


    if (on_off) {
        image(ballon, pos_x, pos_y, ball_size, ball_size);
    }
    if (on_off_horizontale) {
        if (modeAdulte == false) {
            for (i = 1; i < 6; i++) {
                pos_x = i * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
                image(ballon, pos_x, pos_y, ball_size, ball_size);
            }
        }
        else {
            for (i = 0; i < 7; i++) {
                pos_x = i * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
                image(ballon, pos_x, pos_y, ball_size, ball_size);
            }
        }
    }
    if (on_off_verticale) {
        if (modeAdulte == false) {
            for (i = 1; i < 4; i++) {
                pos_y = hauteur - i * largeur_case + (largeur_case - ball_size) / 2;
                image(ballon, pos_x, pos_y, ball_size, ball_size);
            }
        }
        else {
            for (i = 1; i < 5; i++) {
                pos_y = hauteur - i * largeur_case + (largeur_case - ball_size) / 2;
                image(ballon, pos_x, pos_y, ball_size, ball_size);
            }
        }
    }
    if (on_off_aleatoire) {
        if (modeAdulte == false) {
            i = random([1, 2, 3, 4, 5]);
            j = random([1, 2, 3]);
        }
        else {
            i = random([0, 1, 2, 3, 4, 5, 6]);
            j = random([1, 2, 3, 4]);
        }

        {
            pos_x = i * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
            pos_y = hauteur - j * largeur_case + (largeur_case - ball_size) / 2;
            image(ballon, pos_x, pos_y, ball_size, ball_size);
        }
    }
}

function mousePressed() {
    if (mouseX <= largeur - int_poteau && mouseX >= int_poteau && mouseY <= hauteur && mouseY >= int_poteau) {
        if (modeAdulte == false || typeProgramme == "Enfant") {
            if (mouseX <= int_poteau + largeur_case || mouseX >= int_poteau + 6 * largeur_case || mouseY <= int_poteau + largeur_case) {
                if (typeProgramme == "Manuel") {
                    $('#checkPinModal').modal('show');
                    return;
                }
                else {
                    $('#typeProgrammeModal').modal('show');
                    return;
                }
            }
        }
        if (sweepcode == 3) {
            on_off = true;
            abscisse = int(map(mouseX, int_poteau, largeur - int_poteau, 0, 7));
            ordonnee = int(map(mouseY, hauteur, int_poteau, 1, 5));
            $("[name=abscisse]").val(abscisse);
            $("[name=ordonnee]").val(ordonnee);
            $("[name=abscisse]").trigger("change");
            pos_x = abscisse * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
            pos_y = hauteur - ordonnee * largeur_case + (largeur_case - ball_size) / 2;
        }
        else if (sweepcode == 1) {
            on_off_horizontale = true;
            ordonnee = int(map(mouseY, hauteur, int_poteau, 1, 5));
            abscisse = int(map(mouseX, int_poteau, largeur - int_poteau, 0, 7));
            $("[name=ordonnee]").val(ordonnee);
            $("[name=abscisse]").val(abscisse);
            pos_y = hauteur - ordonnee * largeur_case + (largeur_case - ball_size) / 2;
        }
        else if (sweepcode == 2) {
            on_off_verticale = true;
            ordonnee = int(map(mouseY, hauteur, int_poteau, 1, 5));
            abscisse = int(map(mouseX, int_poteau, largeur - int_poteau, 0, 7));
            $("[name=abscisse]").val(abscisse);
            $("[name=ordonnee]").val(ordonnee);
            pos_x = abscisse * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
        }
        else if (sweepcode == 4) {

        }
    }
}

function windowResized() {
    largeur_donnee = $("#cage").width() * 0.95;
    marge = int(0.03 * largeur_donnee);
    int_poteau = int(0.06 * largeur_donnee);
    largeur_case = int(0.12 * largeur_donnee);
    largeur = int_poteau * 2 + 7 * largeur_case;
    hauteur = 4 * largeur_case + int_poteau;
    ball_size = int(0.9 * largeur_case);
    pos_x = abscisse * largeur_case + int_poteau + (largeur_case - ball_size) / 2;
    pos_y = hauteur - ordonnee * largeur_case + (largeur_case - ball_size) / 2;
    resizeCanvas(largeur, hauteur + 10);
}