$(".deleteTir").click(function (e) {
    e.preventDefault();
    $("#confirmDeleteTirModal").modal('show');
    thisDelete = $(this);
});


$("#confirmDeleteTir").click(function (e) {
    e.preventDefault();
    $.post('/Joueur/joueur/supprimer/tir', { titreTir: thisDelete.attr('name'), programme: thisDelete.attr('programme') });
    thisDelete.parent().parent().remove();
    $("#confirmDeleteTirModal").modal('hide');
})

$(".deleteProg").click(function (e) {
    e.preventDefault();
    $("#confirmDeleteProgModal").modal('show');
    thisDelete = $(this);
});


$("#confirmDeleteProg").click(function (e) {
    e.preventDefault();
    $.ajax({
        method: "DELETE",
        url: "/api/joueur/data/" + programme,
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                window.location.href = "/Joueur/joueur/choix/programme/" + "successSuppr"
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
})

$("#newTirForm").submit(function (e) {
    e.preventDefault();
    window.location.href = "/Joueur/joueur/creation/tir/" + programme + "/" + $(this).serializeArray()[0].value;
})
