
$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

$(".puissance").on("changemax", function (event, arg) {
    if (arg == 'adulte') {
        console.log("there");
        $(".puissance").attr('max', 6);
        $(".puissance").val(1);
    }
});

$(".tirCreationForm").on("change", function () {
    if ($(this).get(0).checkValidity()) {
        $("#bouton").prop('disabled', false);
    }
    else {
        $("#bouton").prop('disabled', true);
    }
});

$(".tirCreationForm").trigger("change");

$("#formTirGardien").change(function () {
    $.ajax({
        method: "PREPARE",
        url: "/api/gardien/commande/tir",
        data: $(this).serialize()
    })
        .done(checkAlarms());
});
$("#formTirGardien").submit(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "SHOOT",
        url: "/api/gardien/commande/tir",
        data: $(this).serialize()
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Commande recu, tir imminant"
                }, {
                        type: "success"
                    });
            }
            if (data.success == false) {
                if (data.message == "alarmeProximite") {
                    $('#alarmeIntrusionModal').modal('show');

                }
                else {
                    $.notify({
                        message: data.message
                    }, {
                            type: "danger"
                        });
                }
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur de communication s'est produite"
            }, {
                    type: "danger"
                });
        });
});

$("#stopButton").click(function (e) {
    e.preventDefault(e);
    $.ajax({
        method: "STOP",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "Le tir à bien été annulé"
                }, {
                        type: "success"
                    });
                $('#arretUrgenceModal').modal('show');
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});

$("#rearmButton").click(function () {
    $.ajax({
        method: "REARM",
        url: "/api/parametres/commande"
    })
        .done(function (data, status, head) {
            checkAfterShoot();
            checkAlarms();
            if (data.success == true) {
                $.notify({
                    message: "Lanceur de nouveau prêt à tirer"
                }, {
                        type: "success"
                    });
            }
        })
        .fail(function () {
            checkAfterShoot();
            checkAlarms();
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});

