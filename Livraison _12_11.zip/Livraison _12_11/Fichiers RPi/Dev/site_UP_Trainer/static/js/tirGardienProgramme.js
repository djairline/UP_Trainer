
////////////////////////////////////Décalration variables////////////////////////////////////

var typeProgramme = "Enfant";

/////////////////////////////////////Liste des fonctions////////////////////////////////////

var countdown = {
	seconds: 0,
	interval: 0,
	callback: null,
	init: function () {
		$("#btn-shoot").addClass("btn-disable");
		$("#span-decount").show();
		$("#span-decount").text(countdown.seconds);
		countdown.interval = setInterval(countdown.run, 1000);
	},
	run: function () {
		if (countdown.seconds <= 1) {
			countdown.clear();
			countdown.callback();
		}
		else {
			countdown.seconds = countdown.seconds - 1;
			$("#span-decount").text(countdown.seconds);
		}
	},
	clear: function () {
		clearInterval(countdown.interval);
		$("#span-decount").hide();
		$("#btn-shoot").removeClass("btn-disable");
	}
}

function nextShoot(index, repetition, nbRepetitions, nbTir) {
	if (index >= nbTir - 1 && repetition >= nbRepetitions) {
		$('.liste-texte').removeClass('active');
		$("#indexRepetition").remove();
	}
	else {
		if (repetition >= nbRepetitions) {
			makeActive(index + 1, 1, 0);
		}
		else {
			makeActive(index, repetition + 1, 0);
		}
	}
}

function shoot(programme, tir) {
	$.ajax({
		method: "SHOOT",
		url: "/api/gardien/data/" + programme + "/" + tir
	})
		.done(function (data, status, head) {
			checkAfterShoot();
			checkAlarms();
			if (data.success == true) {
				$.notify({
					message: "Commande recu, tir imminant"
				}, {
						type: "success"
					});
			}
			if (data.success == false) {
				if (data.message == "alarmeProximite") {
					$('#alarmeIntrusionModal').modal('show');

				}
				else {
					$.notify({
						message: data.message
					}, {
							type: "danger"
						});
				}
			}
		})
		.fail(function () {
			checkAfterShoot();
			checkAlarms();
			$.notify({
				message: "Une erreur de communication s'est produite"
			}, {
					type: "danger"
				});
		});
}

function makeActive(index, repetition, wait) {
	countdown.clear();
	$('#btn-shoot').off("click");
	indexTir = repetition;
	for (var i = 0; i < index; i++) {
		indexTir = indexTir + parseInt(tirs[i].repetitions);
	}

	$('.liste-texte').removeClass('active');
	$("#tir" + index).addClass('active');
	$("#indexRepetition").remove();
	$("#tir" + index).append("<span id='indexRepetition' class='ml-auto mr-4 badge badge-light'>" + repetition + "/" + tirs[index].repetitions + "</span>");
	$("#tir").text(indexTir);
	$('input[name=delais]').val(tirs[index].delais);
	$('input[name=puissance]').val(tirs[index].puissance);
	$('input[name=abscisse]').val(tirs[index].abscisse);
	$('input[name=ordonnee]').val(tirs[index].ordonnee);


	$.ajax({
		method: "PREPARE",
		url: "/api/gardien/data/" + programme + "/" + tirs[index].titre
	});

	var shootAndPass = function () {
		shoot(programme, tirs[index].titre);
		nextShoot(index, repetition, tirs[index].repetitions, tirs.length);
	}

	if (tirs[index].lancement == "bouton") {
		$("#cadence").hide();
		$('#btn-shoot').one("click", shootAndPass);
	}
	else {
		$("#cadence").show();
		countdown.seconds = tirs[index].delais;
		countdown.callback = shootAndPass;
		if (wait == 1) {
			$('#btn-shoot').one("click", function () { countdown.init() });
		}
		else {
			countdown.init()
		}
	}
}

/////////////////////////////////////Methode pour aller chercher la liste des tirs////////////////////////////////////

$(document).ready(function () {
	$.ajax({
		method: "GET",
		url: "/api/gardien/data/" + programme
	})
		.done(function (data, status) {
			var nbTir = 0;
			typeProgramme = data.type;
			tirs = data.tirs;
			for (var tir in tirs) {
				$("#items").append("<li class='liste-texte tirProg' id='tir" + tir + "'>" + tirs[tir].titre + "</li>");
				nbTir = nbTir + parseInt(tirs[tir].repetitions);
			}

			$("#nbTir").text(nbTir);
			makeActive(0, 1, 1);

			$('.liste-texte').click(function () {
				makeActive($('.liste-texte').index($(this)), 1, 1);
			});
		});


	/////////////////////////////////////Gestion Des évenements////////////////////////////////////

	$("#stopButton").click(function (e) {
		e.preventDefault(e);
		countdown.clear();
		makeActive(0, 1, 1);
		$.ajax({
			method: "STOP",
			url: "/api/parametres/commande"
		})
			.done(function (data, status, head) {
				if (data.success == true) {
					$.notify({
						message: "Le tir à bien été annulé"
					}, {
							type: "success"
						});
					$('#arretUrgenceModal').modal('show');
				}
			})
			.fail(function () {
				$.notify({
					message: "Une erreur c'est produite"
				}, {
						type: "danger"
					});
			});
	});


	$("#rearmButton").click(function () {
		$.ajax({
			method: "REARM",
			url: "/api/parametres/commande"
		})
			.done(function (data, status, head) {
				checkAfterShoot();
				checkAlarms();
				if (data.success == true) {
					$.notify({
						message: "Lanceur de nouveau prêt à tirer"
					}, {
							type: "success"
						});
				}
			})
			.fail(function () {
				checkAfterShoot();
				checkAlarms();
				$.notify({
					message: "Une erreur c'est produite"
				}, {
						type: "danger"
					});
			});
	});
});
