var compteur;
var sweepcode;

$(".puissance").on("input", function () {
    $(".puissance").val($(this).val());
});

if (sweep == "aléatoire") {
    sweepcode = 0;
}
else if (sweep == "horizontale") {
    sweepcode = 1;
}
else if (sweep == "verticale") {
    sweepcode = 2;
}
else {
    sweepcode = 4;
}
$('input').on("change", function () {
    if ($('input[name=lancement]:checked').val() == "bouton") {
        $("#cadence").hide();
    }
    else {
        $("#cadence").show();
    }
});

$(".angleupt").on("input", function () {
    $(".angleupt").val($(this).val());
});



$("#formTirGardien").submit(function (e) {
    e.preventDefault(e);
    console.log("here");


    $.ajax({
        method: "SHOOT",
        url: "/api/gardien/commande/sequence/" + String(sweepcode),
        data: $(this).serialize()
    })
        .done(function (data, status, head) {
            checkAlarms();
            setInterval(checkAlarms(), 7000);
            if (data.success == true) {
                $.notify({
                    message: "Commande recu, démarrage séquence"
                }, {
                        type: "success"
                    });
            }
            if (data.success == false) {
                $.notify({
                    message: data.message
                }, {
                        type: "danger"
                    });
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});


$("#stopButton").click(function (e) {
    e.preventDefault(e);
    clearInterval(compteur);
    $.ajax({
        method: "STOP",
        url: "/api/gardien/commande/sequence"
    })
        .done(function (data, status, head) {
            if (data.success == true) {
                $.notify({
                    message: "La séquence est terminée"
                }, {
                        type: "success"
                    });
            }
        })
        .fail(function () {
            $.notify({
                message: "Une erreur c'est produite"
            }, {
                    type: "danger"
                });
        });
});
