import subprocess
import time

def checkAlarmIntrusion():
	result = subprocess.run(['./iflanceur', 'GET_INTRUSION?2'], stdout=subprocess.PIPE)
	print(result.stdout.decode('utf-8').rstrip('\n'))
	if int(result.stdout.decode('utf-8').rstrip('\n'))<1500:
		print('_______________________________________________')

def checkStatus():
	temps=time.time()
	result = subprocess.run(['./iflanceur', 'GET_STATUS?'], stdout=subprocess.PIPE)
	print([bool(int(x)) for x in bin(int(result.stdout.decode('utf-8').rstrip('\n')))[2:]])
	print("temps =",time.time()-temps)
while 1:
	checkAlarmIntrusion()
	#checkStatus()
	time.sleep(0.25)




