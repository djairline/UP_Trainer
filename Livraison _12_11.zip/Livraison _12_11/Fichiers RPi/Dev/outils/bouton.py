import RPi.GPIO as GPIO
import time
import subprocess
GPIO.setmode(GPIO.BOARD)

GPIO.setup(3, GPIO.IN) 
GPIO.setup(5, GPIO.IN) 
GPIO.setup(7, GPIO.IN) 
GPIO.setup(8, GPIO.IN) 
GPIO.setup(10, GPIO.IN) 
GPIO.setup(11, GPIO.IN) 
GPIO.setup(12, GPIO.IN) 
GPIO.setup(13, GPIO.IN) 

parametres = {
	"puissance":1,
	"hauteur":10,
	"effet":0}


def my_callback(channel):
	global parametres
	result = subprocess.run(['./iflanceur', 'TARGET=1'], stdout=subprocess.PIPE)
	if channel == 12 and parametres["puissance"]>1:
		parametres["puissance"] -=1
		result = subprocess.run(['./iflanceur', 'SET_POWER='+ str(parametres["puissance"])], stdout=subprocess.PIPE)
	elif channel ==13 and parametres["puissance"]<2:
		parametres["puissance"] +=1
		result = subprocess.run(['./iflanceur', 'SET_POWER='+ str(parametres["puissance"])], stdout=subprocess.PIPE)
	elif channel ==7 and parametres["hauteur"]>1:
		parametres["hauteur"] -=1
		result = subprocess.run(['./iflanceur', 'SET_HEIGHT='+ str(parametres["hauteur"])], stdout=subprocess.PIPE)
	elif channel ==8 and parametres["hauteur"]<20:
		parametres["hauteur"] +=1
		result = subprocess.run(['./iflanceur', 'SET_HEIGHT='+ str(parametres["hauteur"])], stdout=subprocess.PIPE)
	elif channel ==10 and parametres["effet"]>-1:
		parametres["effet"] -=1
		if parametres["effet"] == -1:
			result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '1'], stdout=subprocess.PIPE)
		elif parametres["effet"] ==1:
		 	result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '2'], stdout=subprocess.PIPE)
		else:
		 	result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '0'], stdout=subprocess.PIPE)
	elif channel ==11 and parametres["effet"]<1:
		parametres["effet"] +=1
		if parametres["effet"] == -1:
			result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '1'], stdout=subprocess.PIPE)
		elif parametres["effet"] ==1:
		 	result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '2'], stdout=subprocess.PIPE)
		else:
		 	result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '0'], stdout=subprocess.PIPE)
	elif channel == 3:
		print("shoot")
		result = subprocess.run(['./iflanceur', 'TARGET=1'], stdout=subprocess.PIPE)
		result = subprocess.run(['./iflanceur', 'SET_POWER='+ str(parametres["puissance"])], stdout=subprocess.PIPE)
		result = subprocess.run(['./iflanceur', 'SET_HEIGHT='+ str(parametres["hauteur"])], stdout=subprocess.PIPE)
		if parametres["effet"] == -1:
			result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '1'], stdout=subprocess.PIPE)
		elif parametres["effet"] ==1:
		 	result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '2'], stdout=subprocess.PIPE)
		else:
			result = subprocess.run(['./iflanceur', 'SET_EFFECT='+ '0'], stdout=subprocess.PIPE)
		result = subprocess.run(['./iflanceur', 'SHOOT'], stdout=subprocess.PIPE)
	elif channel ==5:
		print("_________________________break____________________________________")
		result = subprocess.run(['./iflanceur', 'STOP_SHOOT'], stdout=subprocess.PIPE)
	else:
		print("une erreur s'est produite")




	print(parametres)

GPIO.add_event_detect(3, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(5, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(7, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(8, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(10, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(11, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(12, GPIO.RISING, callback=my_callback, bouncetime=500)
GPIO.add_event_detect(13, GPIO.RISING, callback=my_callback, bouncetime=500)

while(True):
	print("Processing")
	time.sleep(10)